package com.ar.bcbs.ad.dao;

public class DBConnectObject {
	
	//object elements
	String dbType;
    String host;
    String username;
    String password;
    String integratedSecurity;
    String query;
    
    //getter methods
    public String getDbType() {
    	return this.dbType;
    }
    public String getHost() {
    	return this.host;
    }
    public String getUsername() {
    	return this.username;
    }
    public String getPassword() {
    	return this.password;
    }
    public String getQuery() {
    	return this.query;
    }
    public String getIntegratedSecurity() {
    	return this.integratedSecurity;
    }
    
    //setter methods
    public void setDbType(String dbType) {
    	this.dbType = dbType;
    }
    public void setHost(String host) {
    	this.host = host;
    }
    public void setUsername(String username) {
    	this.username = username;
    }
    public void setPassword(String password) {
    	this.password = password;
    }
    public void setIntegratedSecurity(String integratedSecurity) {
    	this.integratedSecurity = integratedSecurity;
    }
    public void setQuery(String query) {
    	this.query = query;
    }

}
