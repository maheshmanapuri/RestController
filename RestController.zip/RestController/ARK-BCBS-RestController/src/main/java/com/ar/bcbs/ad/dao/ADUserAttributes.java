package com.ar.bcbs.ad.dao;

import java.util.List;

public class ADUserAttributes {
	
	private String firstName;
	private String middleName;
	private String lastName;
	private String phone;
	private String email;
	private String title;
	private String company;
	//LoginName,sAMAccountName and cn should be the same
	private String loginName;
	private String sAMAccountName;
	private String cn;
	private List<String> memberOf;
	private String distinguishedName;
	private String userPrincipalName;
	private String displayName;
	private String baseUserDN;
	private String cognosTenantId;
	private boolean isAccountEnable;
	
	//Added feild for internal user authentication user type
		private String userType;
	
	//added for Admin Screen
	private String pwdLastSet;
	private boolean isAccountLocked;
	private int noOfBadAttempts;
	private boolean isPasswordExpired;
	
	//Added additional Fields
			private String physicalDeliveryOfficeName;
			private String streetAddress;
			private String division;
			private String manager;
			private String department;

			
			@Override
			public String toString() {
			  return getClass().getSimpleName() + "[firstName=" + firstName + "][middleName=" + middleName + "][lastName=" + lastName + "][phone=" + phone + "][email=" + email + "][title=" + title + "][company=" + company + "]" +
			  		"[loginName=" + loginName + "][sAMAccountName=" + sAMAccountName + "][cn=" + cn + "][memberOf=" + memberOf + "][distinguishedName=" + distinguishedName + "][userPrincipalName=" + userPrincipalName + "]" +
			  				"[displayName=" + displayName + "][physicalDeliveryOfficeName=" + physicalDeliveryOfficeName + "][streetAddress=" + streetAddress + "][division=" + division + "]"
			  						+ "[manager=" + manager + "][department=" + department + "][baseUserDN=" + baseUserDN + "]";
		
		}

	//Gets and Setters
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getsAMAccountName() {
		return sAMAccountName;
	}

	public void setsAMAccountName(String sAMAccountName) {
		this.sAMAccountName = sAMAccountName;
	}

	public String getCn() {
		return cn;
	}

	public void setCn(String cn) {
		this.cn = cn;
	}

	public List<String> getMemberOf() {
		return memberOf;
	}

	public void setMemberOf(List<String> memberOf) {
		this.memberOf = memberOf;
	}

	public String getDistinguishedName() {
		return distinguishedName;
	}

	public void setDistinguishedName(String distinguishedName) {
		this.distinguishedName = distinguishedName;
	}

	public String getUserPrincipalName() {
		return userPrincipalName;
	}

	public void setUserPrincipalName(String userPrincipalName) {
		this.userPrincipalName = userPrincipalName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getBaseUserDN() {
		return baseUserDN;
	}

	public void setBaseUserDN(String baseUserDN) {
		this.baseUserDN = baseUserDN;
	}

	public String getCognosTenantId() {
		return cognosTenantId;
	}

	public void setCognosTenantId(String cognosTenantId) {
		this.cognosTenantId = cognosTenantId;
	}

	public boolean isAccountEnable() {
		return isAccountEnable;
	}

	public void setAccountEnable(boolean isAccountEnable) {
		this.isAccountEnable = isAccountEnable;
	}

	public String getPhysicalDeliveryOfficeName() {
		return physicalDeliveryOfficeName;
	}

	public void setPhysicalDeliveryOfficeName(String physicalDeliveryOfficeName) {
		this.physicalDeliveryOfficeName = physicalDeliveryOfficeName;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getPwdLastSet() {
		return pwdLastSet;
	}

	public void setPwdLastSet(String pwdLastSet) {
		this.pwdLastSet = pwdLastSet;
	}

	public boolean isAccountLocked() {
		return isAccountLocked;
	}

	public void setAccountLocked(boolean isAccountLocked) {
		this.isAccountLocked = isAccountLocked;
	}

	public int getNoOfBadAttempts() {
		return noOfBadAttempts;
	}

	public void setNoOfBadAttempts(int noOfBadAttempts) {
		this.noOfBadAttempts = noOfBadAttempts;
	}

	public boolean isPasswordExpired() {
		return isPasswordExpired;
	}

	public void setPasswordExpired(boolean isPasswordExpired) {
		this.isPasswordExpired = isPasswordExpired;
	}
	
	
}
