package com.ar.bcbs.ad.dao;

public class ADGroupAttributes {
	private String groupName;
	private String groupCN;
	private String baseGroupDN;
	private String description;
	private String notes;
	
	
	//Getters and Setters
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getGroupCN() {
		return groupCN;
	}
	public void setGroupCN(String groupCN) {
		this.groupCN = groupCN;
	}
	public String getBaseGroupDN() {
		return baseGroupDN;
	}
	public void setBaseGroupDN(String baseGroupDN) {
		this.baseGroupDN = baseGroupDN;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}

	
	
}
