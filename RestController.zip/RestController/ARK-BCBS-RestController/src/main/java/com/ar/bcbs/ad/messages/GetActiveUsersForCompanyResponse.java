package com.ar.bcbs.ad.messages;

import java.util.List;

import com.ar.bcbs.ad.dao.UserInfoBPM;

public class GetActiveUsersForCompanyResponse {
	private List<UserInfoBPM> users;

	public List<UserInfoBPM> getUsers() {
		return users;
	}

	public void setUsers(List<UserInfoBPM> users) {
		this.users = users;
	}
	
	
}
