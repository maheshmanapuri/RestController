package com.ar.bcbs.ad.messages;

/**
 * @author Administrator
 *
 */
public class AuthenticateUserResponse {
	private boolean isCredentialValid;
	private String token;
	public boolean isCredentialValid() {
		return isCredentialValid;
	}
	public void setCredentialValid(boolean isCredentialValid) {
		this.isCredentialValid = isCredentialValid;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}	
}
