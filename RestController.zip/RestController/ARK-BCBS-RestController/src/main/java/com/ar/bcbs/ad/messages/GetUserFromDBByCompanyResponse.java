package com.ar.bcbs.ad.messages;

import java.util.List;

import com.ar.bcbs.ad.dao.UserCreationRequest;

public class GetUserFromDBByCompanyResponse {
	private List<UserCreationRequest> items;

	public List<UserCreationRequest> getItems() {
		return items;
	}

	public void setItems(List<UserCreationRequest> items) {
		this.items = items;
	}
}
