package com.ar.bcbs.ad.dao;

public class AdditionalUserInfoBPM {
	private boolean isPermissionPending;
	private boolean isTrainingPending;
	private ReAuthInfo reAuthInfo;
	public boolean isPermissionPending() {
		return isPermissionPending;
	}
	public void setPermissionPending(boolean isPermissionPending) {
		this.isPermissionPending = isPermissionPending;
	}
	public boolean isTrainingPending() {
		return isTrainingPending;
	}
	public void setTrainingPending(boolean isTrainingPending) {
		this.isTrainingPending = isTrainingPending;
	}
	public ReAuthInfo getReAuthInfo() {
		return reAuthInfo;
	}
	public void setReAuthInfo(ReAuthInfo reAuthInfo) {
		this.reAuthInfo = reAuthInfo;
	}
	
	
}
