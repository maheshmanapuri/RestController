package com.ar.bcbs.ad.dao;

public class ADConnectionConfiguration {

	private String user;
	private String password;
	private String ADServer1;
	private String ADServer2;
	private String domain;
	private String userBaseDN;
	private String groupBaseDN;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getADServer1() {
		return ADServer1;
	}
	public void setADServer1(String aDServer1) {
		ADServer1 = aDServer1;
	}
	public String getADServer2() {
		return ADServer2;
	}
	public void setADServer2(String aDServer2) {
		ADServer2 = aDServer2;
	}
	public String getUserBaseDN() {
		return userBaseDN;
	}
	public void setUserBaseDN(String userBaseDN) {
		this.userBaseDN = userBaseDN;
	}
	public String getGroupBaseDN() {
		return groupBaseDN;
	}
	public void setGroupBaseDN(String groupBaseDN) {
		this.groupBaseDN = groupBaseDN;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	
	
}
