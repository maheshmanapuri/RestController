package com.ar.bcbs.ad.messages;

import java.util.List;

import com.ar.bcbs.ad.dao.BPMSearchAliases;
import com.ar.bcbs.ad.dao.BPMSearchConditions;
import com.ar.bcbs.ad.dao.BPMSearchSort;

public class BPMADHocSearchRequest {
	private String interaction;
	private List<String> fields;
	private List<BPMSearchAliases> aliases;
	private List<BPMSearchSort> sort;
	private List<BPMSearchConditions> conditions;
	public String getInteraction() {
		return interaction;
	}
	public void setInteraction(String interaction) {
		this.interaction = interaction;
	}
	public List<String> getFields() {
		return fields;
	}
	public void setFields(List<String> fields) {
		this.fields = fields;
	}
	public List<BPMSearchAliases> getAliases() {
		return aliases;
	}
	public void setAliases(List<BPMSearchAliases> aliases) {
		this.aliases = aliases;
	}
	public List<BPMSearchSort> getSort() {
		return sort;
	}
	public void setSort(List<BPMSearchSort> sort) {
		this.sort = sort;
	}
	public List<BPMSearchConditions> getConditions() {
		return conditions;
	}
	public void setConditions(List<BPMSearchConditions> conditions) {
		this.conditions = conditions;
	}
	
	
}
