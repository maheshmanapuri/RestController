package com.ar.bcbs.service;

import java.util.List;

import com.ar.bcbs.bo.ThieaAuditInfo;

public interface APIServices {

	public List<ThieaAuditInfo> getTheiaAuditInfoForUsers(List<String> usernames) throws Exception;
}
