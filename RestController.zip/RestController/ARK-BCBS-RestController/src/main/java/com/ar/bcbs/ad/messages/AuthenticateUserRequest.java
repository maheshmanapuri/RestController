package com.ar.bcbs.ad.messages;

import com.ar.bcbs.ad.dao.ADConnectionConfiguration;

public class AuthenticateUserRequest {
	private ADConnectionConfiguration adConnectionConfig;
	private String login;
	private String password;
	public ADConnectionConfiguration getAdConnectionConfig() {
		return adConnectionConfig;
	}
	public void setAdConnectionConfig(ADConnectionConfiguration adConnectionConfig) {
		this.adConnectionConfig = adConnectionConfig;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
