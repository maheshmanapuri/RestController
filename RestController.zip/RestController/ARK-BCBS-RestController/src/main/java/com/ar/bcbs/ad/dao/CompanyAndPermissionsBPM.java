package com.ar.bcbs.ad.dao;

public class CompanyAndPermissionsBPM {
	private Integer id;
	private Integer companyId;
	private String name;
	private String sourceCode;
	private String selfFundInd;
	private String reportingType;
	private String excessLossReporting;
	private Boolean isSecure;
	private Boolean pii;
	private String caLastName;
	private String Stephanie;
	private String caTitle;
	private String caPhone;
	private String caEmail;
	private String rmFirstName;
	private String rmLastName;
	private String rmTitle;
	private String rmPhone;
	private String rmEmail;
	private String sourceCodeWithSelfFund;
	private boolean isPermissionPending;
	private boolean isTrainingPending;
	private ReAuthInfo reAuthInfo;
	private boolean isBAA;
	private String baaAttestation;
	private String sensitiveReportJustification;
	private boolean isAccountDisabled;
	
	private CompanyAndPermissionsBPM companyAndPermissions;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSourceCode() {
		return sourceCode;
	}
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	public String getSelfFundInd() {
		return selfFundInd;
	}
	public void setSelfFundInd(String selfFundInd) {
		this.selfFundInd = selfFundInd;
	}
	public String getReportingType() {
		return reportingType;
	}
	public void setReportingType(String reportingType) {
		this.reportingType = reportingType;
	}
	public String getExcessLossReporting() {
		return excessLossReporting;
	}
	public void setExcessLossReporting(String excessLossReporting) {
		this.excessLossReporting = excessLossReporting;
	}
	public Boolean getIsSecure() {
		return isSecure;
	}
	public void setIsSecure(Boolean isSecure) {
		this.isSecure = isSecure;
	}
	public Boolean getPii() {
		return pii;
	}
	public void setPii(Boolean pii) {
		this.pii = pii;
	}
	public String getCaLastName() {
		return caLastName;
	}
	public void setCaLastName(String caLastName) {
		this.caLastName = caLastName;
	}
	public String getStephanie() {
		return Stephanie;
	}
	public void setStephanie(String stephanie) {
		Stephanie = stephanie;
	}
	public String getCaTitle() {
		return caTitle;
	}
	public void setCaTitle(String caTitle) {
		this.caTitle = caTitle;
	}
	public String getCaPhone() {
		return caPhone;
	}
	public void setCaPhone(String caPhone) {
		this.caPhone = caPhone;
	}
	public String getCaEmail() {
		return caEmail;
	}
	public void setCaEmail(String caEmail) {
		this.caEmail = caEmail;
	}
	public String getRmFirstName() {
		return rmFirstName;
	}
	public void setRmFirstName(String rmFirstName) {
		this.rmFirstName = rmFirstName;
	}
	public String getRmLastName() {
		return rmLastName;
	}
	public void setRmLastName(String rmLastName) {
		this.rmLastName = rmLastName;
	}
	public String getRmTitle() {
		return rmTitle;
	}
	public void setRmTitle(String rmTitle) {
		this.rmTitle = rmTitle;
	}
	public String getRmPhone() {
		return rmPhone;
	}
	public void setRmPhone(String rmPhone) {
		this.rmPhone = rmPhone;
	}
	public String getRmEmail() {
		return rmEmail;
	}
	public void setRmEmail(String rmEmail) {
		this.rmEmail = rmEmail;
	}
	public String getSourceCodeWithSelfFund() {
		return sourceCodeWithSelfFund;
	}
	public void setSourceCodeWithSelfFund(String sourceCodeWithSelfFund) {
		this.sourceCodeWithSelfFund = sourceCodeWithSelfFund;
	}
	public CompanyAndPermissionsBPM getCompanyAndPermissions() {
		return companyAndPermissions;
	}
	public void setCompanyAndPermissions(CompanyAndPermissionsBPM companyAndPermissions) {
		this.companyAndPermissions = companyAndPermissions;
	}
	public boolean isPermissionPending() {
		return isPermissionPending;
	}
	public void setPermissionPending(boolean isPermissionPending) {
		this.isPermissionPending = isPermissionPending;
	}
	public ReAuthInfo getReAuthInfo() {
		return reAuthInfo;
	}
	public void setReAuthInfo(ReAuthInfo reAuthInfo) {
		this.reAuthInfo = reAuthInfo;
	}
	public boolean isTrainingPending() {
		return isTrainingPending;
	}
	public void setTrainingPending(boolean isTrainingPending) {
		this.isTrainingPending = isTrainingPending;
	}
	public boolean isBAA() {
		return isBAA;
	}
	public void setBAA(boolean isBAA) {
		this.isBAA = isBAA;
	}
	public String getBaaAttestation() {
		return baaAttestation;
	}
	public void setBaaAttestation(String baaAttestation) {
		this.baaAttestation = baaAttestation;
	}
	public String getSensitiveReportJustification() {
		return sensitiveReportJustification;
	}
	public void setSensitiveReportJustification(String sensitiveReportJustification) {
		this.sensitiveReportJustification = sensitiveReportJustification;
	}
	public boolean isAccountDisabled() {
		return isAccountDisabled;
	}
	public void setAccountDisabled(boolean isAccountDisabled) {
		this.isAccountDisabled = isAccountDisabled;
	}
	
	
}
