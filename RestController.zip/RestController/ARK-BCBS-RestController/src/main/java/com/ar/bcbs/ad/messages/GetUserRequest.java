package com.ar.bcbs.ad.messages;

import com.ar.bcbs.ad.dao.ADConnectionConfiguration;

public class GetUserRequest {
	
	private ADConnectionConfiguration adConnectionConfig;
	private String searchParam;
	private String filterSearch;
	public ADConnectionConfiguration getAdConnectionConfig() {
		return adConnectionConfig;
	}
	public void setAdConnectionConfig(ADConnectionConfiguration adConnectionConfig) {
		this.adConnectionConfig = adConnectionConfig;
	}
	public String getSearchParam() {
		return searchParam;
	}
	public void setSearchParam(String searchParam) {
		this.searchParam = searchParam;
	}
	public String getFilterSearch() {
		return filterSearch;
	}
	public void setFilterSearch(String filterSearch) {
		this.filterSearch = filterSearch;
	}

}
