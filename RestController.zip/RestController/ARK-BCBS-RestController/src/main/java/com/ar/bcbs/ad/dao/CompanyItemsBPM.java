package com.ar.bcbs.ad.dao;

import java.util.List;

public class CompanyItemsBPM {
	private List<CompanyAndPermissionsBPM> items;

	public List<CompanyAndPermissionsBPM> getItems() {
		return items;
	}

	public void setItems(List<CompanyAndPermissionsBPM> items) {
		this.items = items;
	}
	
}
