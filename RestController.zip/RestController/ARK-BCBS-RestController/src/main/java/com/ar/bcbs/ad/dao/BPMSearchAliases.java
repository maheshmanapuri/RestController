package com.ar.bcbs.ad.dao;

/**
 * @author Administrator
 *
 */
public class BPMSearchAliases {
 private String field;
 private String alias;
public String getField() {
	return field;
}
public void setField(String field) {
	this.field = field;
}
public String getAlias() {
	return alias;
}
public void setAlias(String alias) {
	this.alias = alias;
}
 
 
}
