package com.ar.bcbs.ad.dao;

public class UserCreationRequest {
	
	private UserInfoBPM userInformation;
	private CompanyItemsBPM companyFlatStructure;
	private AdditionalUserInfoBPM additionalUserInfo;

	public UserInfoBPM getUserInformation() {
		return userInformation;
	}

	public void setUserInformation(UserInfoBPM userInformation) {
		this.userInformation = userInformation;
	}

	public CompanyItemsBPM getCompanyFlatStructure() {
		return companyFlatStructure;
	}

	public void setCompanyFlatStructure(CompanyItemsBPM companyFlatStructure) {
		this.companyFlatStructure = companyFlatStructure;
	}

	public AdditionalUserInfoBPM getAdditionalUserInfo() {
		return additionalUserInfo;
	}

	public void setAdditionalUserInfo(AdditionalUserInfoBPM additionalUserInfo) {
		this.additionalUserInfo = additionalUserInfo;
	}
	
	
}
