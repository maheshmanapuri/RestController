package com.ar.bcbs.service.implementation;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.ar.bcbs.ad.dao.DBConnectObject;
import com.ar.bcbs.ad.util.DBServices;
import com.ar.bcbs.bo.ThieaAuditInfo;
import com.ar.bcbs.service.APIServices;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class APIServicesImpl implements APIServices  {

	final static Logger logger = Logger.getLogger(APIServicesImpl.class);
	
	private DBConnectObject dbObj =null;
	//private Gson gson;
	private static Properties appProps = null;

	private String POSTGRES_DB_HOST;
	@SuppressWarnings("unused")
	private String POSTGRES_DB_PORT;
	private String POSTGRES_DB_USERNAME;
	private String POSTGRES_DB_PASSWORD;
	
	
	public APIServicesImpl() {
		//this.gson = new Gson();
		String rootPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
		String appConfigPath = rootPath + "environment.properties";
		// logger.debug("--Start getAllADGroups--");

		appProps = new Properties();
		try {
			appProps.load(new FileInputStream(appConfigPath));
			
			POSTGRES_DB_HOST = appProps.getProperty("POSTGRES_DB_HOST");
			POSTGRES_DB_PORT = appProps.getProperty("POSTGRES_DB_PORT");
			POSTGRES_DB_USERNAME = appProps.getProperty("POSTGRES_DB_USERNAME");
			POSTGRES_DB_PASSWORD = appProps.getProperty("POSTGRES_DB_PASSWORD");
			
		} catch (IOException e) {
			logger.debug("Exception in Class Override :" + e);
			// e.printStackTrace();
		}
	}
	
	public List<ThieaAuditInfo> getTheiaAuditInfoForUsers(List<String> lstUsernames) {
		logger.debug("--Start getTheiaAuditInfo Service for usernames size--"+lstUsernames.size());
		List<ThieaAuditInfo> lstThieaAuditInfo = null;

		//JsonParser parser = new JsonParser();
		String query = null;
		String strUserNameList = null;
			  
		try 
		{
			if(lstUsernames!=null && lstUsernames.size()>0)
			{
				 strUserNameList = String.join(",", lstUsernames); 
				 strUserNameList = "'"+String.join("','", lstUsernames)+"'"; 
				query = "SELECT A.USERNAME, A.TIMESTAMP, A.DETAILS, A.ACTION FROM THEIA_AUDIT_USER_AUTH  A\n"+
						 "JOIN (SELECT USERNAME, MAX(TIMESTAMP)TIMESTAMPS FROM THEIA_AUDIT_USER_AUTH WHERE ACTION ='LOGON' GROUP BY USERNAME) B\n"+
						 "ON A.USERNAME = B.USERNAME and A.TIMESTAMP = b.TIMESTAMPS\n"+
				 		 "WHERE UPPER(A.USERNAME) IN ("+strUserNameList.toUpperCase()+")";
				
			}else
			{
				return lstThieaAuditInfo;
			}
			DBServices dbService = new DBServices();
			dbObj  = new DBConnectObject();
			dbObj.setHost(POSTGRES_DB_HOST);
			dbObj.setPassword(POSTGRES_DB_PASSWORD);
			dbObj.setUsername(POSTGRES_DB_USERNAME);
			dbObj.setDbType("postgres");
			dbObj.setIntegratedSecurity("false");
			dbObj.setQuery(query);
			
			Response queryDB = dbService.queryDB(dbObj);
			//parser = new JsonParser();
			
			String responseQueryBody = queryDB.readEntity(String.class);
			JsonObject queryBodyObj = JsonParser.parseString(responseQueryBody).getAsJsonObject();
			logger.debug("<---queryBodyObj--------->" + queryBodyObj);
			
			JsonArray responseArray = null;
			responseArray = queryBodyObj.getAsJsonArray("response");
			if(!responseArray.isJsonNull()) {
				lstThieaAuditInfo = new ArrayList<ThieaAuditInfo>();
				ThieaAuditInfo currentTheiaAuditInfo = null;
				for (int count=0;count<responseArray.size();count++) {
					currentTheiaAuditInfo = new ThieaAuditInfo();
					currentTheiaAuditInfo.setUserName((!responseArray.get(count).getAsJsonObject().get("username").isJsonNull())? responseArray.get(count).getAsJsonObject().get("username").getAsString():null);
					currentTheiaAuditInfo.setDetails((!responseArray.get(count).getAsJsonObject().get("details").isJsonNull())?responseArray.get(count).getAsJsonObject().get("details").getAsString():null);
					currentTheiaAuditInfo.setTimestamp((!responseArray.get(count).getAsJsonObject().get("timestamp").isJsonNull())?responseArray.get(count).getAsJsonObject().get("timestamp").getAsString():null);
					currentTheiaAuditInfo.setAction((!responseArray.get(count).getAsJsonObject().get("action").isJsonNull())?responseArray.get(count).getAsJsonObject().get("action").getAsString():null);
					lstThieaAuditInfo.add(currentTheiaAuditInfo);
				}
			}
			else {
				return lstThieaAuditInfo;
			}
			
			logger.debug("--End getTheiaAuditInfo--");
			return lstThieaAuditInfo;
						
		} catch (Exception exception) {
			logger.debug("Caught Exception in getTheiaAuditInfo " + exception);
			return lstThieaAuditInfo;

		}
	}
}
