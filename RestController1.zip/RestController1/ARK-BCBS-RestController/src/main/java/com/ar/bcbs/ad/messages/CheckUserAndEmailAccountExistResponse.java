package com.ar.bcbs.ad.messages;

public class CheckUserAndEmailAccountExistResponse {
	
	private boolean existUser;
	private boolean existEmail;
	public boolean isExistUser() {
		return existUser;
	}
	public void setExistUser(boolean existUser) {
		this.existUser = existUser;
	}
	public boolean isExistEmail() {
		return existEmail;
	}
	public void setExistEmail(boolean existEmail) {
		this.existEmail = existEmail;
	}
}
