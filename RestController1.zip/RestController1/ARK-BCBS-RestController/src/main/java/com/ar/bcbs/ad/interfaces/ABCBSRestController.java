package com.ar.bcbs.ad.interfaces;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import org.apache.log4j.Logger;
import org.glassfish.jersey.apache.connector.ApacheConnectorProvider;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import com.ar.bcbs.ad.dao.ADConnectionConfiguration;
import com.ar.bcbs.ad.dao.ADUserAttributes;
import com.ar.bcbs.ad.dao.BPMSearchAliases;
import com.ar.bcbs.ad.dao.BPMSearchConditions;
import com.ar.bcbs.ad.dao.BPMSearchSort;
import com.ar.bcbs.ad.dao.DBConnectObject;
import com.ar.bcbs.ad.dao.UserCreationRequest;
import com.ar.bcbs.ad.dao.UserInfoBPM;
import com.ar.bcbs.ad.messages.AuthenticateUserRequest;
import com.ar.bcbs.ad.messages.BPMADHocSearchRequest;
import com.ar.bcbs.ad.messages.CheckUserAndEmailAccountExistRequest;
import com.ar.bcbs.ad.messages.GetActiveUsersForCompanyResponse;
import com.ar.bcbs.ad.messages.GetUserFromDBByCompanyResponse;
import com.ar.bcbs.ad.messages.GetUserRequest;
import com.ar.bcbs.ad.messages.SearchActiveDirectory;
import com.ar.bcbs.ad.util.DBServices;
import com.ar.bcbs.bo.ThieaAuditInfo;
import com.ar.bcbs.service.APIServices;
import com.ar.bcbs.service.implementation.APIServicesImpl;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

@Path("services")
@Provider
public class ABCBSRestController {
	private Gson gson;

	// private Client client;
	private String BPM_USERNAME = null;
	private String BPM_PASSWORD = null;
	private String BPM_URL = null;
	@SuppressWarnings("unused")
	private String INTERNAL_TOMCAT = null;
	private String BPM_DB_SCHEMA = null;
	private DBConnectObject dbObj =null;

	private ADConnectionConfiguration adConnectionConfig;
	private ADConnectionConfiguration adInternalConnectionConfig;
	// private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd
	// HH:mm:ss");
	private static Properties appProps = null;

	final static Logger logger = Logger.getLogger(ABCBSRestController.class);
	APIServices apiServices = new APIServicesImpl();
	
	public ABCBSRestController() {
		this.gson = new Gson();
		String rootPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
		String appConfigPath = rootPath + "environment.properties";
		// logger.debug("--Start getAllADGroups--");

		appProps = new Properties();
		try {
			appProps.load(new FileInputStream(appConfigPath));
			
			dbObj  = new DBConnectObject();
			dbObj.setHost(appProps.getProperty("BPM_DB_HOST"));
			dbObj.setPassword(appProps.getProperty("BPM_DB_PASSWORD"));
			dbObj.setUsername(appProps.getProperty("BPM_DB_USERNAME"));
			BPM_DB_SCHEMA = appProps.getProperty("BPM_DB_SCHEMA");
			
			adConnectionConfig = new ADConnectionConfiguration();
			adInternalConnectionConfig = new ADConnectionConfiguration();

			BPM_USERNAME = appProps.getProperty("BPM_USERNAME");
			BPM_PASSWORD = appProps.getProperty("BPM_PASSWORD");
			BPM_URL = appProps.getProperty("BPM_URL");
			INTERNAL_TOMCAT = appProps.getProperty("INTERNAL_TOMCAT");
			
			
			//External AD
			adConnectionConfig.setADServer1(appProps.getProperty("AD_SERVER_1_HOST").toString());
			adConnectionConfig.setADServer2(appProps.getProperty("AD_SERVER_2_HOST"));
			adConnectionConfig.setDomain(appProps.getProperty("AD_DOMAIN"));
			adConnectionConfig.setGroupBaseDN(appProps.getProperty("AD_GROUP_BASE_DN"));
			adConnectionConfig.setUserBaseDN(appProps.getProperty("AD_USER_BASE_DN"));
			adConnectionConfig.setPassword(appProps.getProperty("AD_PASSWORD"));
			adConnectionConfig.setUser(appProps.getProperty("AD_USER"));
			System.out.println("internal before");
			//Internal AD
			adInternalConnectionConfig.setADServer1(appProps.getProperty("AD_INTERNAL_SERVER_1_HOST").toString());
			adInternalConnectionConfig.setADServer2(appProps.getProperty("AD_INTERNAL_SERVER_2_HOST").toString());
			adInternalConnectionConfig.setDomain(appProps.getProperty("AD_INTERNAL_DOMAIN"));
			adInternalConnectionConfig.setGroupBaseDN(appProps.getProperty("AD_INTERNAL_GROUP_BASE_DN"));
			adInternalConnectionConfig.setUserBaseDN(appProps.getProperty("AD_INTERNAL_USER_BASE_DN"));
			adInternalConnectionConfig.setPassword(appProps.getProperty("AD_INTERNAL_PASSWORD"));
			adInternalConnectionConfig.setUser(appProps.getProperty("AD_INTERNAL_USER"));
			System.out.println("internal after");
			
		} catch (IOException e) {
			logger.debug("Exception in Class Override :" + e);
			// e.printStackTrace();
		}

		// Client client = ClientBuilder.newClient();
		// HttpAuthenticationFeature feature =
		// HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		// client.register(feature);
	}

	/**
	 * @param login
	 *            - login name of the user without the CN or DN
	 * @return boolean - true if user exists in AD
	 * @throws Exception
	 */
	@POST
	@Path("authenticateUser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response authenticateMe(AuthenticateUserRequest authenticateUserRequest) throws Exception {
		logger.debug("--Start authenticateUser Service 2--");

		JsonObject jsonObject = new JsonObject();
		String result = "";

		try {

			ActiveDirectoryBPMInterface activeDirectory = new ActiveDirectoryBPMInterface();
			authenticateUserRequest.setAdConnectionConfig(adConnectionConfig);
			Response response = activeDirectory.authenticateUserCredentials(authenticateUserRequest);
			

			//JsonParser parser = new JsonParser();

			if (response.getStatus() == 403) {
				logger.debug("403 forbidden---");
				return Response.status(Response.Status.FORBIDDEN).build();
			}
			String responseBody = response.getEntity().toString();
			if (response.getStatus() == 200) {

				JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
				JsonPrimitive responseJSON = o.getAsJsonPrimitive("response");

				String token = null;
				Date tokenExpireDate = new java.util.Date();

				// convert date to calendar
				Calendar c = Calendar.getInstance();
				c.setTime(tokenExpireDate);

				// manipulate date
				// c.add(Calendar.DATE, 1); //same with c.add(Calendar.DAY_OF_MONTH, 1);
				c.add(Calendar.MINUTE, 120);
				// convert calendar to date
				Date currentDatePlusOne = c.getTime();

				// logger.debug(dateFormat.format(currentDatePlusOne));

				Algorithm algorithm = Algorithm.HMAC256("T0K3N@BcB$");
				token = JWT.create().withSubject("User Authentication").withExpiresAt(currentDatePlusOne)
						.withClaim("UserInformation", (responseBody == null) ? null : responseJSON.getAsString())
						.withIssuer("auth0").sign(algorithm);

				logger.debug("--End authenticateMe--");
				jsonObject.addProperty("response", token);
				result = "" + jsonObject;
				return Response.status(200).entity(result).build();

			} else {
				return Response.status(200).entity(responseBody).build();
			}
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();

		}
	}
	
	/**
	 * @param login
	 *            - login name of the user without the CN or DN
	 * @return boolean - true if user exists in AD
	 * @throws Exception
	 */
	@POST
	@Path("authenticateInternalUser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response authenticateIntenalUser(AuthenticateUserRequest authenticateUserRequest) throws Exception {
		logger.debug("--Start authenticateIntenalUser Service --");

		//Hardcoded values--Start
		authenticateUserRequest.setLogin("axrajan");
		authenticateUserRequest.setPassword("Fall@2020Oct");
		
		//end
		JsonObject jsonObject = new JsonObject();
		String result = "";
		ADUserAttributes adUser = null;
		Boolean validAdminUser =false;

		try {
			//Call Active Directory Service to authenticate user
			ActiveDirectoryBPMInterface activeDirectory = new ActiveDirectoryBPMInterface();
			authenticateUserRequest.setAdConnectionConfig(adInternalConnectionConfig);
			Response response = activeDirectory.authenticateInternalUserCredentials(authenticateUserRequest);
			

			//JsonParser parser = new JsonParser();
			if (response.getStatus() == 403) {
				logger.debug("403 forbidden---");
				return Response.status(Response.Status.FORBIDDEN).build();
			}
			String responseBody = response.getEntity().toString();
			
			//if Authenticated check if AMAA or PCV Approver
			if (response.getStatus() == 200) {

				JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
				JsonPrimitive responseJSON = o.getAsJsonPrimitive("response");
				adUser = gson.fromJson(responseJSON.getAsString(), ADUserAttributes.class);
				
				//remove hardcode
				//adUser.setEmail("arajan@ztech.io");
				//adUser.setUserType("APA");
				//remove --End
				
				String query = "USE "+BPM_DB_SCHEMA+"\n"+
						"Select COUNT(*)NO_OF_RECORDS from DBO.ama_info WHERE EMAIL = '"+adUser.getEmail()+"'";
				DBServices dbService = new DBServices();
				dbObj.setDbType("sql server");
				dbObj.setIntegratedSecurity("false");
				dbObj.setQuery(query);
				
				
				Integer recordCount = 0;
				Response queryDB = dbService.queryDB(dbObj);
			
				
				String responseQueryBody = queryDB.readEntity(String.class);
				JsonObject queryBodyObj = JsonParser.parseString(responseQueryBody).getAsJsonObject();
				logger.debug("<---queryBodyObj--------->" + queryBodyObj);
				
				JsonArray responseArray = null;
				responseArray = queryBodyObj.getAsJsonArray("response");
				if(!responseArray.isJsonNull()&&!responseArray.get(0).isJsonNull()) {
					recordCount = responseArray.get(0).getAsJsonObject().get("NO_OF_RECORDS").getAsInt();
					
				}
				
				if(recordCount!=0) {
					adUser.setUserType("AMAA");
					validAdminUser = true;
				}
				else 
				{
					
					
					String responseBPMTeamBody = (String) getUsersFromBPMTeam("PCV Approver").getEntity();
					
					JsonObject bpmTeamObj = JsonParser.parseString(responseBPMTeamBody).getAsJsonObject();
					
					JsonArray responseBPMTeamArray = null;
					responseBPMTeamArray = bpmTeamObj.getAsJsonArray("response");
					if(!responseBPMTeamArray.isJsonNull()) {
						for(int count=0; count<responseBPMTeamArray.size();count++)
						{
							System.out.println("Response from Get BPM Team-->"+responseBPMTeamArray.get(count).getAsJsonObject().get("name").getAsString());
							if(adUser.getEmail().equalsIgnoreCase(responseBPMTeamArray.get(count).getAsJsonObject().get("name").getAsString())) {
								adUser.setUserType("PCV Approver");
								validAdminUser = true;
								break;
							}
								
						}
					}
				}
					
				
				if(validAdminUser) 
				{
					String token = null;
					Date tokenExpireDate = new java.util.Date();
	
					// convert date to calendar
					Calendar c = Calendar.getInstance();
					c.setTime(tokenExpireDate);
	
					// manipulate date
					// c.add(Calendar.DATE, 1); //same with c.add(Calendar.DAY_OF_MONTH, 1);
					c.add(Calendar.MINUTE, 120);
					// convert calendar to date
					Date currentDatePlusOne = c.getTime();
	
					// logger.debug(dateFormat.format(currentDatePlusOne));
					logger.debug("--before End authenticateMe--");
					Algorithm algorithm = Algorithm.HMAC256("T0K3N@BcB$");
					token = JWT.create().withSubject("User Authentication").withExpiresAt(currentDatePlusOne)
							.withClaim("UserInformation", gson.toJson(adUser))
							.withIssuer("auth0").sign(algorithm);
	
					logger.debug("--End authenticateInternalUser--");
					jsonObject.addProperty("response", token);
					result = "" + jsonObject;
					return Response.status(200).entity(result).build();
				}else
				{
					
					
					jsonObject.addProperty("response", "UNAUTHORIZED");
					result = "" + jsonObject;
					return Response.status(401).entity(result).build();
				}
				

			} else {
				return Response.status(200).entity(responseBody).build();
			}
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();

		}
	}

	/**
	 * @param login
	 *            - login name of the user without the CN or DN
	 * @return boolean - true if user exists in AD
	 * @throws Exception
	 */
	@POST
	@Path("checkUserAndEmailAccountExist")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response checkUserAndEmailAccountExist(CheckUserAndEmailAccountExistRequest checkUserAndEmailAccountExist)
			throws Exception {
		logger.debug("--Start checkUserAndEmailAccountExist--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		//Client client = ClientBuilder.newClient();

		try {

			ActiveDirectoryBPMInterface activeDirectory = new ActiveDirectoryBPMInterface();
			checkUserAndEmailAccountExist.setAdConnectionConfig(adConnectionConfig);
			Response response = activeDirectory.checkUserAndEmailAccountExist(checkUserAndEmailAccountExist);
			String responseBody = response.getEntity().toString();

			if (response.getStatus() == 403) {
				logger.debug("403 forbidden---");
				return Response.status(Response.Status.FORBIDDEN).build();
			}
			if (response.getStatus() == 200) {
				return Response.status(200).entity(responseBody).build();
			} else {
				return Response.status(501).entity(responseBody).build();
			}
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();

		}
	}

	/**
	 * @param taskId
	 *            - taskID for getTaskDetails
	 * @return json - bpm rest response
	 * @throws Exception
	 */

	@GET
	@Path("bpmoc/getTaskDetails/{taskId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getTaskDetails(@PathParam("taskId") String taskId) throws Exception {

		logger.debug("--Start getTaskDetails for--: " + taskId);

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("part", "all")
					.request(MediaType.APPLICATION_JSON).get();

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param taskId
	 *            - taskID for getTaskDetails
	 * @return json - bpm rest response
	 * @throws Exception
	 */

	@PUT
	@Path("bpmoc/assigntask/{taskId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response assignTask(@PathParam("taskId") String taskId) throws Exception {
		logger.debug("--Start assignTask to External for--: " + taskId);

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("action", "assign")
					.queryParam("toMe", "true").request(MediaType.APPLICATION_JSON)
					.put(Entity.entity("", MediaType.APPLICATION_JSON));

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param taskId
	 *            - taskID for re-assign task back to owner
	 * @return JSON - BPM rest response
	 * @throws Exception
	 */

	@PUT
	@Path("bpmoc/assigntaskBack/{taskId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response assigntaskBack(@PathParam("taskId") String taskId) throws Exception {
		logger.debug("--Start assignTask to Original Owner for--: " + taskId);

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("action", "assign")
					.queryParam("back", "true").request(MediaType.APPLICATION_JSON)
					.put(Entity.entity("", MediaType.APPLICATION_JSON));

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param taskId
	 *            -taskId to complete Task
	 * @param completeJSONRequest
	 *            -completeJSONRequest to complete Task
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("bpmoc/completetask/{taskId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response completeTask(@PathParam("taskId") String taskId, String completeJSONRequest) throws Exception {
		logger.debug("--Start completetask--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Form form = new Form();
			form.param("action", "complete").param("params", completeJSONRequest);
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("action", "complete")
					.queryParam("part", "all").request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}

	/**
	 * @param searchParam
	 *            - ad search string
	 * @param filterSearch
	 *            - memberOf/samaccountname/email
	 * @return boolean - true if user exists in AD
	 * @throws Exception
	 */
	@POST
	@Path("searchActiveDirectory")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response searchActiveDirectory(SearchActiveDirectory searchActiveDirectory) throws Exception {
		logger.debug("--Start searchActiveDirectory--");

		JsonObject jsonObject = new JsonObject();
		String result = "";

		try {
			GetUserRequest getUserRequest = new GetUserRequest();
			getUserRequest.setAdConnectionConfig(adConnectionConfig);
			getUserRequest.setSearchParam(searchActiveDirectory.getSearchParam());
			getUserRequest.setFilterSearch(searchActiveDirectory.getFilterSearch());

			ActiveDirectoryBPMInterface activeDirectory = new ActiveDirectoryBPMInterface();
			Response response = activeDirectory.getUser(getUserRequest);
			String responseBody = response.getEntity().toString();

			//JsonParser parser = new JsonParser();

			if (response.getStatus() == 403) {
				logger.debug("403 forbidden---");
				return Response.status(Response.Status.FORBIDDEN).build();
			}
			if (response.getStatus() == 200) {
				JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
				JsonPrimitive responseJSON = o.getAsJsonPrimitive("response");
				logger.debug("--End searchActiveDirectory--" + responseJSON);

				return Response.status(200).entity(responseBody).build();

			} else {
				return Response.status(501).entity(responseBody).build();
			}
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();

		}
	}

	/**
	 * @param company
	 *            - company for getInflightUserOnboarding
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("bpmoc/getInflightUserOnboarding/{company}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getInflightUserOnboarding(@PathParam("company") String company) throws Exception {

		logger.debug("--Start getInflightUserOnboarding-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		String jsonRequestForm = "{\"company\":\"" + company + "\"}";
		Form form = new Form().param("params", jsonRequestForm);

		try {
			Response response = client.target(BPM_URL)
					.path("/service/BCBSONB%40DB%20Get%20Inflight%20User%20Onboarding%20Data")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			JsonArray inflightUserOnboardingListItems = null;
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

			logger.debug("<---inflightUserOnboardingList--------->"
					+ dataJsonObj.get("inflightUserOnboardingList").isJsonNull());
			if (!dataJsonObj.get("inflightUserOnboardingList").isJsonNull()) {
				JsonObject inflightUserOnboardingList = o.getAsJsonObject("data").getAsJsonObject("data")
						.getAsJsonObject("inflightUserOnboardingList");
				if (!inflightUserOnboardingList.isJsonNull()
						&& (!inflightUserOnboardingList.getAsJsonArray("items").isJsonNull()
								&& inflightUserOnboardingList.getAsJsonArray("items").size() > 0)) {
					inflightUserOnboardingListItems = inflightUserOnboardingList.getAsJsonArray("items");
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(inflightUserOnboardingListItems);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);

				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}
	
	/**
	 * @param company
	 *            - company for getInflightUserOnboarding
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("bpmoc/getInflightUserOnboardingByUser/{adminEmail}/{adminType}/{userEmail}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getInflightUserOnboardingByUser(@PathParam("userEmail") String userEmail) throws Exception {

		logger.debug("--Start getInflightUserOnboardingByUser-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		String jsonRequestForm = "{\"userEmail\":\"" + userEmail + "\"}";
		Form form = new Form().param("params", jsonRequestForm);

		try {
			Response response = client.target(BPM_URL)
					.path("/service/BCBSONB%40DB%20Get%20Inflight%20User%20Onboarding%20By%20User%20Data")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			JsonArray inflightUserOnboardingListItems = null;
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

			logger.debug("<---inflightUserOnboardingList--------->"
					+ dataJsonObj.get("inflightUserOnboardingList").isJsonNull());
			if (!dataJsonObj.get("inflightUserOnboardingList").isJsonNull()) {
				JsonObject inflightUserOnboardingList = o.getAsJsonObject("data").getAsJsonObject("data")
						.getAsJsonObject("inflightUserOnboardingList");
				if (!inflightUserOnboardingList.isJsonNull()
						&& (!inflightUserOnboardingList.getAsJsonArray("items").isJsonNull()
								&& inflightUserOnboardingList.getAsJsonArray("items").size() > 0)) {
					inflightUserOnboardingListItems = inflightUserOnboardingList.getAsJsonArray("items");
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(inflightUserOnboardingListItems);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);

				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param company
	 *            - company name
	 * @param userEmail
	 *            - users email
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("bpmoc/initateUserOnboardingProcess")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response initateUserOnboardingProcess(String completeJSONRequest) throws Exception {
		logger.debug("--Start initateUserOnboardingProcess--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Form form = new Form();
			form.param("action", "complete").param("params", completeJSONRequest);
			Response response = client.target(BPM_URL).path("process").queryParam("action", "start")
					.queryParam("bpdId", "25.85c8e71d-6ed0-444d-9a74-5358ada9a13d")
					.queryParam("processAppId", "2066.f4b32441-58c6-4728-8009-15f1b67dc278").queryParam("part", "all")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			// https://arkbluecross.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/process?action=start&bpdId=&processAppId=&params=%7B%22userEmail%22%3A%22test%40test.com%22%2C%22company%22%3A%22OPPORTUNITIES+INC+(4863)%22%7D&parts=header
			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}

	/**
	 * @param company
	 *            - company name
	 * @param userEmail
	 *            - users email
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("bpmoc/initateUserPermissionsProcess")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response initateUserPermissionsProcess(String completeJSONRequest) throws Exception {
		logger.debug("--Start initateUserPermissionsProcess--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Form form = new Form();
			form.param("action", "complete").param("params", completeJSONRequest);
			Response response = client.target(BPM_URL).path("process").queryParam("action", "start")
					.queryParam("bpdId", "25.26cdedaf-c5b8-4c54-8837-17848d6bed71")
					.queryParam("processAppId", "2066.f4b32441-58c6-4728-8009-15f1b67dc278").queryParam("part", "all")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			// https://arkbluecross.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/process?action=start&bpdId=&processAppId=&params=%7B%22userEmail%22%3A%22test%40test.com%22%2C%22company%22%3A%22OPPORTUNITIES+INC+(4863)%22%7D&parts=header
			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}

	/**
	 * @param company
	 *            - company for getInflightUserOnboarding
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("bpmoc/getTrueSCandSF/{company}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getTrueSCandSF(@PathParam("company") String company) throws Exception {

		logger.debug("--Start getTrueSCandSF-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		String jsonRequestForm = "{\"data\":\"" + company + "\"}";
		Form form = new Form().param("params", jsonRequestForm);

		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40Get%20True%20SC%20SF%20Ajax")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			JsonArray items = null;
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

			logger.debug("<---getTrueSCandSF--------->" + dataJsonObj.get("results").isJsonNull());
			if (!dataJsonObj.get("results").isJsonNull()) {
				JsonObject results = o.getAsJsonObject("data").getAsJsonObject("data").getAsJsonObject("results");
				JsonElement isElReporting = o.getAsJsonObject("data").getAsJsonObject("data").get("elReporting");
				if (!results.isJsonNull() && (!results.getAsJsonArray("items").isJsonNull()
						&& results.getAsJsonArray("items").size() > 0)) {
					items = results.getAsJsonArray("items");
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(items);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);
					responsePayload.add("isELReporting", isElReporting);
					// responsePayload.addProperty("isELReporting", true);
				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param company
	 *            - company for selected source code and self fund
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("bpmoc/getSelectedSCandSFforCompany/{company}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getSelectedSCandSFforCompany(@PathParam("company") String company) throws Exception {

		logger.debug("--Start getSelectedSCandSFforCompany-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		String jsonRequestForm = "{\"data\":\"" + company + "\"}";
		Form form = new Form().param("params", jsonRequestForm);

		try {
			Response response = client.target(BPM_URL)
					.path("/service/BCBSONB%40Get%20Selected%20SC%20SF%20for%20Company").queryParam("action", "start")
					.queryParam("createTask", "false").queryParam("parts", "data").request(MediaType.APPLICATION_JSON)
					.post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			JsonArray items = null;
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

			logger.debug("<---getSelectedSCandSFforCompany--------->" + dataJsonObj.get("results").isJsonNull());
			if (!dataJsonObj.get("results").isJsonNull()) {
				JsonObject results = o.getAsJsonObject("data").getAsJsonObject("data").getAsJsonObject("results");
				JsonElement isElReporting = o.getAsJsonObject("data").getAsJsonObject("data").get("elReporting");
				if (!results.isJsonNull() && (!results.getAsJsonArray("items").isJsonNull()
						&& results.getAsJsonArray("items").size() > 0)) {
					items = results.getAsJsonArray("items");
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(items);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);
					responsePayload.add("isELReporting", isElReporting);
					// responsePayload.addProperty("isELReporting", true);
				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param piid
	 *            - process Instance ID
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("bpmoc/resendUserOnboardingEmail")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response resendUserOnboardingEmail(String completeJSONRequest) throws Exception {

		logger.debug("--Start resendUserOnboardingEmail-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		// String jsonRequestForm = "{\"company\":\""+company+"\"}";
		Form form = new Form().param("params", completeJSONRequest);

		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40ReSendUserEmail_Service")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			// logger.debug("<---o--------->"+o);
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

			logger.debug("<---resendUserOnboardingEmail--------->" + dataJsonObj.get("status").isJsonNull());
			if (!dataJsonObj.get("status").isJsonNull()) {
				JsonObject data = o.getAsJsonObject("data").getAsJsonObject("data");
				if (!data.isJsonNull()) {
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(data);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);

				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param taskId
	 *            - taskID for getTaskDetails
	 * @return json - bpm rest response
	 * @throws Exception
	 */

	@GET
	@Path("bpmoc/getActiveTaskForProcess/{processId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getActiveTaskForProcess(@PathParam("processId") String processId) throws Exception {

		logger.debug("--Start getActiveTaskForProcess for--: " + processId);

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();

		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		// WebTarget webTarget =
		// client.target("https://arkbluecross.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1");
		// WebTarget employeeWebTarget = webTarget.path("task/29679").queryParam("part",
		// "all");

		// Invocation.Builder invocationBuilder =
		// employeeWebTarget.request(MediaType.APPLICATION_JSON);
		// Response response = invocationBuilder.get();
		// https://arkbluecross.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/process/3159/taskSummary/Active
		try {
			Response response = client.target(BPM_URL).path("process/" + processId).queryParam("part", "header")
					.request(MediaType.APPLICATION_JSON).get();

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			// logger.debug("<---o--------->"+o);
			JsonArray taskList = null;
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data");

			logger.debug("<---getActiveTaskForProcess--------->" + dataJsonObj.get("tasks").isJsonNull());
			if (!dataJsonObj.get("tasks").isJsonNull()) {
				JsonObject currentTaskObj;
				// JsonObject inflightUserOnboardingList =
				// o.getAsJsonObject("data").getAsJsonObject("data").getAsJsonObject("inflightUserOnboardingList");
				if (!dataJsonObj.isJsonNull() && (!dataJsonObj.getAsJsonArray("tasks").isJsonNull()
						&& dataJsonObj.getAsJsonArray("tasks").size() > 0)) {
					taskList = dataJsonObj.getAsJsonArray("tasks");
					JsonArray activeTaskList = new JsonArray();
					String status;
					for (int count = 0; count < taskList.size(); count++) {
						currentTaskObj = taskList.get(count).getAsJsonObject();
						status = currentTaskObj.get("status").getAsString().trim();
						if ("Received".equalsIgnoreCase(status)) {
							activeTaskList.add(taskList.get(count));
						}
					}
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(activeTaskList);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);

				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param taskId
	 *            - taskID for getTaskDetails
	 * @return json - bpm rest response
	 * @throws Exception
	 */

	@GET
	@Path("bpmoc/getNeedsClarificationTaskByCompany/{company}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response getNeedsClarificationTaskByCompany(@PathParam("company") String company) throws Exception {
		logger.debug("--Start getNeedsClarificationTaskByCompany for--: " + company);

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		BPMADHocSearchRequest bpmADHocSearchRequest = new BPMADHocSearchRequest();
		ArrayList<String> bpmFields = new ArrayList<String>();
		bpmFields.add("taskSubject");
		bpmFields.add("instanceName");
		bpmFields.add("taskStatus");
		bpmFields.add("companySearch@String");
		bpmFields.add("taskDueDate");
		bpmFields.add("taskId");

		bpmADHocSearchRequest.setInteraction("claimed_and_available");
		bpmADHocSearchRequest.setFields(bpmFields);

		ArrayList<BPMSearchAliases> bpmSearchAliasesList = new ArrayList<BPMSearchAliases>();
		BPMSearchAliases bpmSearchAliases = new BPMSearchAliases();
		bpmSearchAliases.setAlias("Company");
		bpmSearchAliases.setField("companySearch");
		bpmSearchAliasesList.add(bpmSearchAliases);

		bpmADHocSearchRequest.setAliases(bpmSearchAliasesList);

		ArrayList<BPMSearchSort> bpmSearchSortList = new ArrayList<BPMSearchSort>();
		BPMSearchSort bpmSearchSort = new BPMSearchSort();
		bpmSearchSort.setField("taskDueDate");
		bpmSearchSort.setOrder("ASC");
		bpmSearchSortList.add(bpmSearchSort);

		bpmADHocSearchRequest.setSort(bpmSearchSortList);

		ArrayList<BPMSearchConditions> bpmSearchConditionsList = new ArrayList<BPMSearchConditions>();
		BPMSearchConditions bpmSearchConditions = new BPMSearchConditions();
		bpmSearchConditions.setField("companySearch");
		bpmSearchConditions.setOperator("FullTextSearch");
		bpmSearchConditions.setValue(company);
		bpmSearchConditionsList.add(bpmSearchConditions);

		/*
		 * bpmSearchConditions = new BPMSearchConditions();
		 * bpmSearchConditions.setField("taskSubject");
		 * bpmSearchConditions.setOperator("Contains");
		 * bpmSearchConditions.setValue("Need Clarification for PCV User");
		 * bpmSearchConditionsList.add(bpmSearchConditions);
		 * 
		 * 
		 * bpmSearchConditions = new BPMSearchConditions();
		 * bpmSearchConditions.setField("taskSubject");
		 * bpmSearchConditions.setOperator("Contains");
		 * bpmSearchConditions.setValue("Contact Information Updated for");
		 * bpmSearchConditionsList.add(bpmSearchConditions);
		 */

		bpmADHocSearchRequest.setConditions(bpmSearchConditionsList);
		String completeJSONRequest = gson.toJson(bpmADHocSearchRequest);
		// logger.debug("completeJSONRequest---->"+completeJSONRequest);
		try {
			Form form = new Form();
			form.param("params", completeJSONRequest);
			Response response = client.target(BPM_URL).path("tasks").queryParam("filterByCurrentUser", "false")
					.queryParam("calcStats", "false").request(MediaType.APPLICATION_JSON)
					.put(Entity.entity(completeJSONRequest, MediaType.APPLICATION_JSON));

			// logger.debug("response"+response.toString());
			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			logger.debug("client.toString())--> " + client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param company
	 * @return list of users for the specific company
	 * @throws Exception
	 */
	@GET
	@Path("getActiveUsersForCompany/{company}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getActiveUsersForCompany(@PathParam("company") String company) throws Exception {
		logger.debug("--Start getActiveUsersForCompany--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		Client client = ClientBuilder.newClient();

		try {

			GetUserRequest getUserRequest = new GetUserRequest();
			getUserRequest.setAdConnectionConfig(adConnectionConfig);
			getUserRequest.setSearchParam(company);
			getUserRequest.setFilterSearch("memberOf");

			ActiveDirectoryBPMInterface activeDirectory = new ActiveDirectoryBPMInterface();
			Response response = activeDirectory.searchActiveDirectory(getUserRequest);
			String responseBody = response.getEntity().toString();

			if (response.getStatus() == 403) {
				logger.debug("403 forbidden---");
				return Response.status(Response.Status.FORBIDDEN).build();
			}

			GetActiveUsersForCompanyResponse activeUsersForCompanyResponse = new GetActiveUsersForCompanyResponse();
			List<UserInfoBPM> lstUserInfoBPM = new ArrayList<UserInfoBPM>();
			activeUsersForCompanyResponse.setUsers(lstUserInfoBPM);

			String activeUsersForCompanyResponseJSON = gson.toJson(activeUsersForCompanyResponse);

			if (response.getStatus() == 200) {
				logger.debug("--End searchActiveDirectory--" + responseBody);
				if (responseBody != null) {
					ADUserAttributes[] adUser = gson.fromJson(responseBody, ADUserAttributes[].class);
					if (adUser.length > 0) {

						// GetActiveUsersForCompanyResponse activeUsersForCompanyResponse = new
						// GetActiveUsersForCompanyResponse();
						activeUsersForCompanyResponse = new GetActiveUsersForCompanyResponse();
						// Added
						client.close();
						String getUserFromDBByCompany = (String) getUserFromDBByCompany(company).getEntity();

						GetUserFromDBByCompanyResponse getUserFromDBByCompanyResponse = gson
								.fromJson(getUserFromDBByCompany, GetUserFromDBByCompanyResponse.class);
						HashMap<String, String> uniqueUsers = new HashMap<>();

						HashMap<String, UserCreationRequest> mapUserDB = new HashMap<>();
						if (getUserFromDBByCompanyResponse != null
								&& getUserFromDBByCompanyResponse.getItems() != null) {
							for (int countDBResp = 0; countDBResp < getUserFromDBByCompanyResponse.getItems()
									.size(); countDBResp++) {
								String adLoginName = getUserFromDBByCompanyResponse.getItems().get(countDBResp)
										.getUserInformation().getLogonName();
								mapUserDB.put(adLoginName, getUserFromDBByCompanyResponse.getItems().get(countDBResp));
							}
						}
						// List<UserInfoBPM>lstUserInfoBPM = new ArrayList<UserInfoBPM>();
						lstUserInfoBPM = new ArrayList<UserInfoBPM>();
						for (int countADUserInfo = 0; countADUserInfo < adUser.length; countADUserInfo++) {
							if (mapUserDB.containsKey(adUser[countADUserInfo].getLoginName())) {
								if (!uniqueUsers.containsKey(adUser[countADUserInfo].getLoginName())) {
									uniqueUsers.put(adUser[countADUserInfo].getLoginName(),
											adUser[countADUserInfo].getLoginName());
									UserInfoBPM userInfoBPM = new UserInfoBPM();
									UserCreationRequest currentUserCreationRequest = mapUserDB
											.get(adUser[countADUserInfo].getLoginName());
									userInfoBPM = currentUserCreationRequest.getUserInformation();
									userInfoBPM.setFirstName(adUser[countADUserInfo].getFirstName());
									userInfoBPM.setMiddleName(adUser[countADUserInfo].getMiddleName());
									userInfoBPM.setLastName(adUser[countADUserInfo].getLastName());
									userInfoBPM.setPhone(adUser[countADUserInfo].getPhone());
									userInfoBPM.setTitle(adUser[countADUserInfo].getTitle());
									userInfoBPM.setCompany(adUser[countADUserInfo].getCompany());
									userInfoBPM.setCognosTenantId(adUser[countADUserInfo].getCognosTenantId());
									userInfoBPM.setAccountEnable(adUser[countADUserInfo].isAccountEnable());
									userInfoBPM.setAccountLocked(adUser[countADUserInfo].isAccountLocked());
									
									//Admin Field.. Removing it since it will be on getActiveUsersForCompanyAdminService Method
									/*
									 * userInfoBPM.setPwdLastSet(adUser[countADUserInfo].getPwdLastSet());
									 * userInfoBPM.setAccountLocked(adUser[countADUserInfo].isAccountLocked());
									 * userInfoBPM.setNoOfBadAttempts(adUser[countADUserInfo].getNoOfBadAttempts());
									 * userInfoBPM.setPasswordExpired(adUser[countADUserInfo].isPasswordExpired());
									 */
									//--End
									
									//Setting if the user is an APA
									userInfoBPM.setAPA(false);
									if(adUser[countADUserInfo].getMemberOf()!=null&&adUser[countADUserInfo].getMemberOf().size()>0) {
										for(int count=0;count<adUser[countADUserInfo].getMemberOf().size();count++)
										{
											if(adUser[countADUserInfo].getMemberOf().get(count).indexOf("CN=PCV_APA")>-1) {
												userInfoBPM.setAPA(true);
												break;
											}
											
										}
									}//End

									// Get Company and Permissions
									if (currentUserCreationRequest.getCompanyFlatStructure() != null
											&& (currentUserCreationRequest.getCompanyFlatStructure().getItems() != null
													&& currentUserCreationRequest.getCompanyFlatStructure().getItems()
															.size() > 0)) {
										userInfoBPM.setCompanyAndPermissions(
												currentUserCreationRequest.getCompanyFlatStructure().getItems().get(0));
										if(userInfoBPM.getCompanyAndPermissions().isAccountDisabled()) {
											userInfoBPM.setAccountEnable(false);
										}
									}

									// Getting the Additional UserInformation
									if (currentUserCreationRequest.getAdditionalUserInfo() != null) {
										userInfoBPM.setAdditionalUserInfo(
												currentUserCreationRequest.getAdditionalUserInfo());
									}

									lstUserInfoBPM.add(userInfoBPM);
								}
							}

						}
						activeUsersForCompanyResponse.setUsers(lstUserInfoBPM);

						// logger.debug("--End adUser--"+adUser[0].getFirstName());

						// logger.debug("-getUserFromDBByCompanyResponse--getTenantType---"+getUserFromDBByCompanyResponse.getItems().get(0).getUserInformation().getTenantType());
						// String activeUsersForCompanyResponseJSON =
						// gson.toJson(activeUsersForCompanyResponse);
						activeUsersForCompanyResponseJSON = gson.toJson(activeUsersForCompanyResponse);
						return Response.status(200).entity(activeUsersForCompanyResponseJSON).build();
					} else {
						/*
						 * jsonObject = new JsonObject(); jsonObject.addProperty("response", "");
						 * result= ""+jsonObject; return Response.status(200).entity(result).build();
						 */
						return Response.status(200).entity(activeUsersForCompanyResponseJSON).build();
					}

				} else {
					/*
					 * jsonObject = new JsonObject(); jsonObject.addProperty("response", "");
					 * result= ""+jsonObject; return Response.status(200).entity(result).build();
					 */
					return Response.status(200).entity(activeUsersForCompanyResponseJSON).build();
				}

			} else {
				return Response.status(501).entity(responseBody).build();
			}
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();

		}
	}

	/**
	 * @param company
	 *            - company for getInflightUserOnboarding
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("bpmoc/getUserFromDBByCompany/{company}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response getUserFromDBByCompany(@PathParam("company") String company) throws Exception {

		logger.debug("--Start getUserFromDBByCompany-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		String jsonRequestForm = "{\"company\":\"" + company + "\"}";
		Form form = new Form().param("params", jsonRequestForm);

		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40DB_Get%20User%20Info%20By%20Company")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");
			UserCreationRequest userCreationRequest = gson.fromJson(dataJsonObj, UserCreationRequest.class);

			// logger.debug("<---userCreationRequest---getRecordId----->"+userCreationRequest.getRecordId());
			logger.debug("<---getUserFromDBByCompany---getRecordId----->" + userCreationRequest.getUserInformation());
			// logger.debug("<---getUserFromDBByCompany--------->"+dataJsonObj.get("userCreationRequest").isJsonNull());
			if (!dataJsonObj.get("userCreationRequest").isJsonNull()) {
				JsonObject inflightUserOnboardingList = o.getAsJsonObject("data").getAsJsonObject("data")
						.getAsJsonObject("userCreationRequest");
				if (!inflightUserOnboardingList.isJsonNull()
						&& (!inflightUserOnboardingList.getAsJsonArray("items").isJsonNull()
								&& inflightUserOnboardingList.getAsJsonArray("items").size() > 0)) {
					GetUserFromDBByCompanyResponse getUserFromDBByCompanyResponse = gson
							.fromJson(inflightUserOnboardingList, GetUserFromDBByCompanyResponse.class);
					logger.debug("<---getUserFromDBByCompanyResponse---size----->"
							+ getUserFromDBByCompanyResponse.getItems().size());
					logger.debug("<---getUserFromDBByCompanyResponse--getTenantType----->"
							+ getUserFromDBByCompanyResponse.getItems().get(0).getUserInformation().getTenantType());

					String getUserFromDBByCompanyJson = gson.toJson(getUserFromDBByCompanyResponse);

					jsonObject.addProperty("response", getUserFromDBByCompanyJson);
					result = "" + jsonObject;
					logger.debug("--End getUserFromDBByCompany--");
					return Response.status(200).entity(getUserFromDBByCompanyJson).build();

				}
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param piid
	 *            - process Instance ID
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("bpmoc/deleteUser")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response deleteUser(String completeJSONRequest) throws Exception {

		logger.debug("--Start deleteUser-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		// String jsonRequestForm = "{\"company\":\""+company+"\"}";
		Form form = new Form().param("params", completeJSONRequest);

		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40Delete_User_Service")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			String responseString = null;

			JsonElement dataJsonObj = o.get("status");

			logger.debug("<---deleteUser--------->" + dataJsonObj.isJsonNull());
			if (!dataJsonObj.isJsonNull()) {

				responsePayload = new JsonObject();
				responsePayload.add("response", dataJsonObj);

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "Failed");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param company
	 *            - company name
	 * @param userEmail
	 *            - users email
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("bpmoc/initiateUserReAuthProcess")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response initiateUserReAuthProcess(String completeJSONRequest) throws Exception {
		logger.debug("--Start initiateUserReAuthProcess--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Form form = new Form();
			form.param("action", "complete").param("params", completeJSONRequest);
			Response response = client.target(BPM_URL).path("process").queryParam("action", "start")
					.queryParam("bpdId", "25.1c9f0592-dfba-4e4a-9582-c913d47f92a8")
					.queryParam("processAppId", "2066.f4b32441-58c6-4728-8009-15f1b67dc278").queryParam("part", "all")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			// https://arkbluecross.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/process?action=start&bpdId=&processAppId=&params=%7B%22userEmail%22%3A%22test%40test.com%22%2C%22company%22%3A%22OPPORTUNITIES+INC+(4863)%22%7D&parts=header
			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}

	/**
	 * @param piid
	 *            - process Instance ID
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("bpmoc/deleteUserOnboardingProcess")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response deleteUserOnboardingProcess(String completeJSONRequest) throws Exception {

		logger.debug("--Start deleteUserOnboardingProcess-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		// String jsonRequestForm = "{\"company\":\""+company+"\"}";
		Form form = new Form().param("params", completeJSONRequest);

		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40DeleteUserOnboardingProcess_Service")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			// logger.debug("<---o--------->"+o);
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

			logger.debug("<---deleteUserOnboardingProcess--------->" + dataJsonObj.get("status").isJsonNull());
			if (!dataJsonObj.get("status").isJsonNull()) {
				JsonObject data = o.getAsJsonObject("data").getAsJsonObject("data");
				if (!data.isJsonNull()) {
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(data);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);

				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @return json - bpm rest response
	 * @throws Exception
	 */

	@GET
	@Path("bpmoc/getELCarrierCompanies/")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getELCarrierCompanies() throws Exception {

		logger.debug("--Start getELCarrierCompanies--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		//JsonParser parser = new JsonParser();
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		Form form = new Form();
		List<String> elCarrierCompanies = null;

		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40DB_Get%20EL%20Carrier%20Companies")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			// return Response.status(200).entity(responseBody).build();

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");
			if (!dataJsonObj.get("elCarrierCompanies").isJsonNull()) {
				JsonObject elCarrierCompany = o.getAsJsonObject("data").getAsJsonObject("data")
						.getAsJsonObject("elCarrierCompanies");
				if (!elCarrierCompany.isJsonNull() && (!elCarrierCompany.getAsJsonArray("items").isJsonNull()
						&& elCarrierCompany.getAsJsonArray("items").size() > 0)) {
					elCarrierCompanies = new ArrayList<String>();
					for (int elCarrierCount = 0; elCarrierCount < elCarrierCompany.getAsJsonArray("items")
							.size(); elCarrierCount++) {
						elCarrierCompanies
								.add(elCarrierCompany.getAsJsonArray("items").get(elCarrierCount).getAsString());
					}
				}

			}
			String elCarrierCompaniesJson = gson.toJson(elCarrierCompanies);

			jsonObject.addProperty("response", elCarrierCompaniesJson);
			result = "" + jsonObject;
			logger.debug("--End getELCarrierCompanies--");
			return Response.status(200).entity(elCarrierCompaniesJson).build();
		}

		catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param onboardingExceptionInfo
	 *            - Contains information about the exception
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("bpmoc/initiateOnboardingExceptionProcess")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response initiateOnboardingExceptionProcess(String completeJSONRequest) throws Exception {
		logger.debug("--Start initiateOnboardingExceptionProcess--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Form form = new Form();
			form.param("action", "complete").param("params", completeJSONRequest);
			Response response = client.target(BPM_URL).path("process").queryParam("action", "start")
					.queryParam("bpdId", "25.000a9ed4-5a9e-4f33-9c03-c0d48efbe470")
					.queryParam("processAppId", "2066.f4b32441-58c6-4728-8009-15f1b67dc278").queryParam("part", "all")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			// https://arkbluecross.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/process?action=start&bpdId=&processAppId=&params=%7B%22userEmail%22%3A%22test%40test.com%22%2C%22company%22%3A%22OPPORTUNITIES+INC+(4863)%22%7D&parts=header
			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}

	/**
	 * @param adloginName
	 *            - login name for user
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("bpmoc/getUserInfoFromDB/{adLoginName}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response getUserInfoFromDB(@PathParam("adLoginName") String adLoginName) throws Exception {

		logger.debug("--Start getUserInfoFromDB-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		// clientBuilder.withConfig(clientConfig);
		// client = clientBuilder.build();

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		//JsonParser parser = new JsonParser();
		String jsonRequestForm = "{\"adLoginName\":\"" + adLoginName + "\"}";
		Form form = new Form().param("params", jsonRequestForm);

		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40DB_Get%20User%20Request%20from%20DB")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");
			if (!dataJsonObj.get("userCreationRequest").isJsonNull()) {
				JsonObject userCreationRequestJSON = o.getAsJsonObject("data").getAsJsonObject("data")
						.getAsJsonObject("userCreationRequest");
				if (!userCreationRequestJSON.isJsonNull()) {
					UserCreationRequest UserCreationRequest = gson.fromJson(userCreationRequestJSON,
							UserCreationRequest.class);
					logger.debug("<---getUserInfoFromDB---Retreived Data----->");

					String getUserFromDBByCompanyJson = gson.toJson(UserCreationRequest);

					jsonObject.addProperty("response", getUserFromDBByCompanyJson);
					result = "" + jsonObject;
					logger.debug("--End getUserInfoFromDB--");
					return Response.status(200).entity(getUserFromDBByCompanyJson).build();

				}
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "No Records Found");
				responseString = responsePayload.toString();
				return Response.status(201).entity(responseString).build();
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * 
	 * @return json - current env property
	 * @throws Exception
	 */
	@GET
	@Path("getCurrentEnvProperties")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getCurrentEnvProperties() throws Exception {

		// logger.debug("--Start getCurrentEnvProperties-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";

		try {
			responsePayload = new JsonObject();
			responsePayload.addProperty("response", BPM_URL);

			String responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param company
	 *            - company for getInflightUserOnboarding
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("bpmoc/getUsersFromBPMTeam/{bpmteam}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response getUsersFromBPMTeam(@PathParam("bpmteam") String bpmteam) throws Exception {

		logger.debug("--Start getUsersFromBPMTeam-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		String jsonRequestForm = "{\"data\":\"" + bpmteam + "\"}";
		Form form = new Form().param("params", jsonRequestForm);
		
		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40Get%20Users%20from%20BPM%20Team")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			JsonArray items = null;
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

			logger.debug("<---getUsersFromBPMTeam--------->" + dataJsonObj.get("results").isJsonNull());
			if (!dataJsonObj.get("results").isJsonNull()) {
				JsonObject results = o.getAsJsonObject("data").getAsJsonObject("data").getAsJsonObject("results");
				if (!results.isJsonNull() && (!results.getAsJsonArray("items").isJsonNull()
						&& results.getAsJsonArray("items").size() > 0)) {
					items = results.getAsJsonArray("items");
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(items);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);
				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}
	
	
	/**
	 * @param adminEmail
	 *            - PCV Approver or AMAA email
	 * @param userType
	 *            - PCV Approver or AMAA            
	 * @return company List
	 * @throws Exception
	 */
	@GET
	@Path("getCompaniesForAdministration/{adminEmail}/{userType}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response getCompaniesForAdministration(@PathParam("adminEmail") String adminEmail,@PathParam("userType") String userType) throws Exception {
		logger.debug("--Start getCompaniesForAdministration Service for --"+adminEmail);
			
		JsonObject jsonObject = new JsonObject();
		String result = "";
		JsonObject responsePayload = new JsonObject();
		Response response = null;
		
			if(userType.equalsIgnoreCase("AMAA") || userType.equalsIgnoreCase("PCV Approver")) 
			{
							
				// Added to check proxy--Start
				Client client = null;
				// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
				gson = new GsonBuilder().setLenient().create();

				ClientConfig clientConfig = new ClientConfig()
						.connectorProvider(new ApacheConnectorProvider())
						.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

				
				logger.debug("<---New client with Proxy--------->");
				// Added to check proxy--End

				// Added for TSLV1.2
				SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
				System.setProperty("https.protocols", "TLSv1.2");// Java 8

				TrustManager[] trustAllCerts = { new ServerTrustManager() };
				sc.init(null, trustAllCerts, new java.security.SecureRandom());
				HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
				client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
						.build();
				// End

				HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
				client.register(feature);
				//JsonParser parser = new JsonParser();
				String jsonRequestForm = "{\"adminEmail\":\""+adminEmail+"\", \"userType\":\""+userType+"\"}";
				Form form = new Form().param("params", jsonRequestForm);
				
				try {
					 response = client.target(BPM_URL).path("/service/BCBSONB%40DB_Get%20Companies%20for%20Administration")
							.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
							.request(MediaType.APPLICATION_JSON).post(Entity.form(form));
					 
					 String responseBody = response.readEntity(String.class);
						JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
						logger.debug("<---o--------->" + o);
						JsonArray items = null;
						String responseString = null;

						JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

						logger.debug("<---getUsersFromBPMTeam--------->" + dataJsonObj.get("companies").isJsonNull());
						if (!dataJsonObj.get("companies").isJsonNull()) {
							JsonObject results = o.getAsJsonObject("data").getAsJsonObject("data").getAsJsonObject("companies");
							if (!results.isJsonNull() && (!results.getAsJsonArray("items").isJsonNull()
									&& results.getAsJsonArray("items").size() > 0)) {
								items = results.getAsJsonArray("items");
								com.google.gson.JsonElement jsonElement = gson.toJsonTree(items);
								responsePayload = new JsonObject();
								responsePayload.add("response", jsonElement);
							}

							/*
							 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
							 * logger.debug("<------------->");
							 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
							 * o.getAsJsonPrimitive("data"));
							 */
						} else {
							responsePayload = new JsonObject();
							responsePayload.addProperty("response", "");
						}
						responseString = responsePayload.toString();
						return Response.status(200).entity(responseString).build();
			}catch (Exception exception) {
				logger.debug("Caught Exception " + exception);
				jsonObject = new JsonObject();
				jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
				result = "" + jsonObject;
				return Response.status(501).entity(result).build();
			}
			}else
			{
				return Response.status(501).entity("USER TYPE IS REQUIRED").build();
			}
		
			
		
	}
	
	/**
	 * @param companyName       
	 * @return company List
	 * @throws Exception
	 */
	@GET
	@Path("getAPAForCompany/{companyName}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response getAPAForCompany(@PathParam("companyName") String companyName) throws Exception {
		logger.debug("--Start getAPAForCompany Service for company --"+companyName);
		
		//JsonParser parser = new JsonParser();
		JsonObject jsonObject = new JsonObject();
		String result = "";
		String query = null;
		Response getAPAForCompanyResp = null;
		try 
		{
			if(companyName!=null && !"".equalsIgnoreCase(companyName))
			{
				 query = "USE "+BPM_DB_SCHEMA+"\n"+
						 "Select apa.first_name, apa.last_name, apa.email, \n"+
						 "( select top 1 login_timestamp  from apa_login_audit audit where  apa.email = audit.apa_login_email ORDER by login_timestamp DESC) lastLoginTimestamp \n"+
						 "from dbo.company c\n"+
						 "JOIN dbo.apa_info apa\n"+
						 "on c.company_id = apa.company_id\n"+
				 		 "WHERE C.COMPANY_NAME = '"+companyName+"'";
				 System.out.println("Query--->"+query);
				 
			}else
			{
				return Response.status(501).entity("COMPANY NAME IS REQUIRED").build();
			}
				
			
			DBServices dbService = new DBServices();
			dbObj.setDbType("sql server");
			dbObj.setIntegratedSecurity("false");
			dbObj.setQuery(query);
			
			Response queryDB = dbService.queryDB(dbObj);
			String responseSearchADBody = null;
			JsonObject searchADBodyObj = null;
			
			String responseQueryBody = queryDB.readEntity(String.class);
			JsonObject queryBodyObj = JsonParser.parseString(responseQueryBody).getAsJsonObject();
			logger.debug("<---queryBodyObj--------->" + queryBodyObj);
			
			JsonArray responseArray = null;
			String lastLoginTimestamp = null;
			responseArray = queryBodyObj.getAsJsonArray("response");
			if(!responseArray.isJsonNull()&&!responseArray.get(0).isJsonNull()) {
				String apaEmail = responseArray.get(0).getAsJsonObject().get("email").getAsString();
				lastLoginTimestamp = responseArray.get(0).getAsJsonObject().get("lastLoginTimestamp")!=null ? responseArray.get(0).getAsJsonObject().get("lastLoginTimestamp").getAsString() : "N/A";
				if(apaEmail!=null && !"".equalsIgnoreCase(apaEmail))
				{
					SearchActiveDirectory searchActiveDirectory = new SearchActiveDirectory();
					searchActiveDirectory.setSearchParam(apaEmail);
					searchActiveDirectory.setFilterSearch("mail");
					getAPAForCompanyResp  = searchActiveDirectory(searchActiveDirectory);
					
					
					responseSearchADBody = (String) getAPAForCompanyResp.getEntity();
					searchADBodyObj = JsonParser.parseString(responseSearchADBody).getAsJsonObject();
					searchADBodyObj.addProperty("lastManageUserLogin", lastLoginTimestamp);
				
					
				}
				else
					return Response.status(501).entity("COMPANY NOT FOUND").build();
				
			}
			
			logger.debug("--End getAPAForCompany--");
			result =  ""+searchADBodyObj;
			return Response.status(200).entity(result).build();
						
		} catch (Exception exception) {
			logger.debug("Caught Exception in getAPAForCompany " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();

		}
	}
	
	
	/**
	 * @param companyName       
	 * @return company List
	 * @throws Exception
	 */
	@PUT
	@Path("auditAPALogin/{apaEmail}/{timestamp}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response auditAPALogin(@PathParam("apaEmail") String apaEmail,@PathParam("timestamp") String timestamp) throws Exception {
		logger.debug("--Start auditAPALogin Service for apaEmail --"+apaEmail);
		
		//JsonParser parser = new JsonParser();
		JsonObject jsonObject = new JsonObject();
		String result = "";
		String query = null;
		try 
		{
			if(apaEmail!=null && !"".equalsIgnoreCase(apaEmail))
			{
				 query = "USE "+BPM_DB_SCHEMA+"\n"+
						 "Insert into dbo.apa_login_audit (apa_login_email, login_timestamp) "+
						 "VALUES('"+apaEmail+"', '"+timestamp+"')";
						
			}else
			{
				return Response.status(501).entity("APA Email IS REQUIRED").build();
			}
				
			
			DBServices dbService = new DBServices();
			dbObj.setDbType("sql server");
			dbObj.setIntegratedSecurity("false");
			dbObj.setQuery(query);
			
			Response queryDB = dbService.insertDB(dbObj);
			
			
			String responseQueryBody = queryDB.readEntity(String.class);
			JsonObject queryBodyObj = JsonParser.parseString(responseQueryBody).getAsJsonObject();
			logger.debug("<---queryBodyObj--------->" + queryBodyObj);
			
			JsonArray responseArray = null;
			responseArray = queryBodyObj.getAsJsonArray("recordId");
			if(!responseArray.isJsonNull()&&!responseArray.get(0).isJsonNull()&&(responseArray.get(0).getAsLong()>0)) {
				System.out.println("responseArray.get(0).getAsJsonObject()-->"+responseArray.get(0).getAsLong());
				jsonObject.addProperty("response", "success");
				result = "" + jsonObject;
				return Response.status(200).entity(result).build();
			}
				else return
						Response.status(501).entity("COMPANY NOT FOUND").build();
				
			
		} catch (Exception exception) {
			logger.debug("Caught Exception in auditAPALogin " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();

		}
	}
	
	
	/**
	 * @param company
	 * @return list of users for the specific company
	 * @throws Exception
	 */
	@GET
	@Path("getActiveUsersForCompanyAdminService/{company}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
//	@Secured
	public Response getActiveUsersForCompanyAdminService(@PathParam("company") String company) throws Exception {
		logger.debug("--Start getActiveUsersForCompanyAdminService--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		Client client = ClientBuilder.newClient();

		try {

			GetUserRequest getUserRequest = new GetUserRequest();
			getUserRequest.setAdConnectionConfig(adConnectionConfig);
			getUserRequest.setSearchParam(company);
			getUserRequest.setFilterSearch("memberOf");

			ActiveDirectoryBPMInterface activeDirectory = new ActiveDirectoryBPMInterface();
			Response response = activeDirectory.searchActiveDirectory(getUserRequest);
			String responseBody = response.getEntity().toString();

			if (response.getStatus() == 403) {
				logger.debug("403 forbidden---");
				return Response.status(Response.Status.FORBIDDEN).build();
			}

			GetActiveUsersForCompanyResponse activeUsersForCompanyResponse = new GetActiveUsersForCompanyResponse();
			List<UserInfoBPM> lstUserInfoBPM = new ArrayList<UserInfoBPM>();
			activeUsersForCompanyResponse.setUsers(lstUserInfoBPM);

			String activeUsersForCompanyResponseJSON = gson.toJson(activeUsersForCompanyResponse);

			if (response.getStatus() == 200) {
				logger.debug("--End searchActiveDirectory--" + responseBody);
				if (responseBody != null) {
					ADUserAttributes[] adUser = gson.fromJson(responseBody, ADUserAttributes[].class);
					if (adUser.length > 0) {

						// GetActiveUsersForCompanyResponse activeUsersForCompanyResponse = new
						// GetActiveUsersForCompanyResponse();
						activeUsersForCompanyResponse = new GetActiveUsersForCompanyResponse();
						// Added
						client.close();
						String getUserFromDBByCompany = (String) getUserFromDBByCompany(company).getEntity();

						GetUserFromDBByCompanyResponse getUserFromDBByCompanyResponse = gson
								.fromJson(getUserFromDBByCompany, GetUserFromDBByCompanyResponse.class);
						HashMap<String, String> uniqueUsers = new HashMap<>();

						HashMap<String, UserCreationRequest> mapUserDB = new HashMap<>();
						List<String> usernames = null;
						if (getUserFromDBByCompanyResponse != null
								&& getUserFromDBByCompanyResponse.getItems() != null) {
							usernames= new ArrayList<String>();
							for (int countDBResp = 0; countDBResp < getUserFromDBByCompanyResponse.getItems()
									.size(); countDBResp++) {
								String adLoginName = getUserFromDBByCompanyResponse.getItems().get(countDBResp)
										.getUserInformation().getLogonName();
								mapUserDB.put(adLoginName, getUserFromDBByCompanyResponse.getItems().get(countDBResp));
								//This is for getting the information from Theia
								if(getUserFromDBByCompanyResponse.getItems().get(countDBResp)
										.getUserInformation().getTenantType()!=null && !"Internal".equalsIgnoreCase(getUserFromDBByCompanyResponse.getItems().get(countDBResp).getUserInformation().getTenantType())) {
									usernames.add(getUserFromDBByCompanyResponse.getItems().get(countDBResp).getUserInformation().getEmail());
								}
								else {
									usernames.add(getUserFromDBByCompanyResponse.getItems().get(countDBResp).getUserInformation().getLogonName());
								}
									
							}
							//usernames = new ArrayList<String>(mapUserDB.keySet());
							
						}
						
						
						//If usernames list not null, get the information from Theia for all the users
						HashMap<String, ThieaAuditInfo> mapThieaInfo = new HashMap<>();
						if(usernames!=null && usernames.size()>0) {
							List<ThieaAuditInfo> lstTheiaAuditInfo = apiServices.getTheiaAuditInfoForUsers(usernames) ;
							for(ThieaAuditInfo thieaAuditInfo : lstTheiaAuditInfo) {
								mapThieaInfo.put(thieaAuditInfo.getUserName(),thieaAuditInfo);
							}
						}
						
						// List<UserInfoBPM>lstUserInfoBPM = new ArrayList<UserInfoBPM>();
						lstUserInfoBPM = new ArrayList<UserInfoBPM>();
						for (int countADUserInfo = 0; countADUserInfo < adUser.length; countADUserInfo++) {
							if (mapUserDB.containsKey(adUser[countADUserInfo].getLoginName())) {
								if (!uniqueUsers.containsKey(adUser[countADUserInfo].getLoginName())) {
									uniqueUsers.put(adUser[countADUserInfo].getLoginName(),
											adUser[countADUserInfo].getLoginName());
									UserInfoBPM userInfoBPM = new UserInfoBPM();
									UserCreationRequest currentUserCreationRequest = mapUserDB
											.get(adUser[countADUserInfo].getLoginName());
									userInfoBPM = currentUserCreationRequest.getUserInformation();
									userInfoBPM.setFirstName(adUser[countADUserInfo].getFirstName());
									userInfoBPM.setMiddleName(adUser[countADUserInfo].getMiddleName());
									userInfoBPM.setLastName(adUser[countADUserInfo].getLastName());
									userInfoBPM.setPhone(adUser[countADUserInfo].getPhone());
									userInfoBPM.setTitle(adUser[countADUserInfo].getTitle());
									userInfoBPM.setCompany(adUser[countADUserInfo].getCompany());
									userInfoBPM.setCognosTenantId(adUser[countADUserInfo].getCognosTenantId());
									userInfoBPM.setAccountEnable(adUser[countADUserInfo].isAccountEnable());
									
									userInfoBPM.setPwdLastSet(adUser[countADUserInfo].getPwdLastSet());
									userInfoBPM.setAccountLocked(adUser[countADUserInfo].isAccountLocked());
									userInfoBPM.setNoOfBadAttempts(adUser[countADUserInfo].getNoOfBadAttempts());
									userInfoBPM.setPasswordExpired(adUser[countADUserInfo].isPasswordExpired());
									//Setting Thiea Value
									if(userInfoBPM.getTenantType()!=null && !"Internal".equalsIgnoreCase(userInfoBPM.getTenantType())){
										if(mapThieaInfo.containsKey(adUser[countADUserInfo].getEmail())) {
											ThieaAuditInfo currentThieaAuditInfo = mapThieaInfo.get(adUser[countADUserInfo].getEmail());
											userInfoBPM.setLastTheiaLogin(currentThieaAuditInfo.getTimestamp());
									
										}
									}else {
										if(mapThieaInfo.containsKey(adUser[countADUserInfo].getLoginName())) {
											ThieaAuditInfo currentThieaAuditInfo = mapThieaInfo.get(adUser[countADUserInfo].getLoginName());
											userInfoBPM.setLastTheiaLogin(currentThieaAuditInfo.getTimestamp());
									
										}
									}
									
									
									//Setting if the user is an APA
									userInfoBPM.setAPA(false);
									if(adUser[countADUserInfo].getMemberOf()!=null&&adUser[countADUserInfo].getMemberOf().size()>0) {
										for(int count=0;count<adUser[countADUserInfo].getMemberOf().size();count++)
										{
											if(adUser[countADUserInfo].getMemberOf().get(count).indexOf("CN=PCV_APA")>-1) {
												userInfoBPM.setAPA(true);
												Response getAPAForCompanyResponse = getAPAForCompany(company);
												
												
												
												String responseGetAPAForCompanyBody = (String) getAPAForCompanyResponse.getEntity();
												
												
												JsonObject getAPAForCompanyBodyObj = null;
												getAPAForCompanyBodyObj = JsonParser.parseString(responseGetAPAForCompanyBody).getAsJsonObject();
												logger.debug("<---queryBodyObj--------->" + getAPAForCompanyBodyObj);
												
												String lastMangeUserLogin = !getAPAForCompanyBodyObj.get("lastManageUserLogin").isJsonNull() ? getAPAForCompanyBodyObj.get("lastManageUserLogin").getAsString() : "N/A";
												userInfoBPM.setLastManageUserLogin(lastMangeUserLogin);	
												//System.out.println("lastManageUSeeTimestamp--->"+lastManageUSeeTimestamp);
												
											
												break;
											}
											
										}
									}//End

									// Get Company and Permissions
									if (currentUserCreationRequest.getCompanyFlatStructure() != null
											&& (currentUserCreationRequest.getCompanyFlatStructure().getItems() != null
													&& currentUserCreationRequest.getCompanyFlatStructure().getItems()
															.size() > 0)) {
										userInfoBPM.setCompanyAndPermissions(
												currentUserCreationRequest.getCompanyFlatStructure().getItems().get(0));
										if(userInfoBPM.getCompanyAndPermissions().isAccountDisabled()) {
											userInfoBPM.setAccountEnable(false);
										}
									}

									// Getting the Additional UserInformation
									if (currentUserCreationRequest.getAdditionalUserInfo() != null) {
										userInfoBPM.setAdditionalUserInfo(
												currentUserCreationRequest.getAdditionalUserInfo());
									}

									lstUserInfoBPM.add(userInfoBPM);
								}
							}

						}
						activeUsersForCompanyResponse.setUsers(lstUserInfoBPM);

										activeUsersForCompanyResponseJSON = gson.toJson(activeUsersForCompanyResponse);
						return Response.status(200).entity(activeUsersForCompanyResponseJSON).build();
					} else {
						return Response.status(200).entity(activeUsersForCompanyResponseJSON).build();
					}

				} else {
					return Response.status(200).entity(activeUsersForCompanyResponseJSON).build();
				}

			} else {
				return Response.status(501).entity(responseBody).build();
			}
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();

		}
	}
	
	/**
	 * @param company
	 * @return list of users for the specific company
	 * @throws Exception
	 */
	@GET
	@Path("searchBrokerByAdmin/{adminEmail}/{adminType}/{brokerEmail}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
//	@Secured
	public Response searchBrokerByAdmin(@PathParam("adminEmail") String adminEmail,@PathParam("adminType") String adminType,@PathParam("brokerEmail") String brokerEmail) throws Exception {
		logger.debug("--Start getActiveUsersForCompanyAdminService--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		Client client = ClientBuilder.newClient();

		try {

			GetUserRequest getUserRequest = new GetUserRequest();
			getUserRequest.setAdConnectionConfig(adConnectionConfig);
			getUserRequest.setSearchParam(brokerEmail);
			getUserRequest.setFilterSearch("mail");

			ActiveDirectoryBPMInterface activeDirectory = new ActiveDirectoryBPMInterface();
			Response response = activeDirectory.searchActiveDirectory(getUserRequest);
			String responseBody = response.getEntity().toString();

			if (response.getStatus() == 403) {
				logger.debug("403 forbidden---");
				return Response.status(Response.Status.FORBIDDEN).build();
			}

			GetActiveUsersForCompanyResponse activeUsersForCompanyResponse = new GetActiveUsersForCompanyResponse();
			List<UserInfoBPM> lstUserInfoBPM = new ArrayList<UserInfoBPM>();
			activeUsersForCompanyResponse.setUsers(lstUserInfoBPM);

			String activeUsersForCompanyResponseJSON = gson.toJson(activeUsersForCompanyResponse);

			if (response.getStatus() == 200) {
				logger.debug("--End searchActiveDirectory--" + responseBody);
				if (responseBody != null) {
					ADUserAttributes[] adUser = gson.fromJson(responseBody, ADUserAttributes[].class);
					if (adUser.length > 0) {

						// GetActiveUsersForCompanyResponse activeUsersForCompanyResponse = new
						// GetActiveUsersForCompanyResponse();
						activeUsersForCompanyResponse = new GetActiveUsersForCompanyResponse();
						// Added
						client.close();
						String getUserFromDBByCompany = (String) getUserFromDBByAdminType(adminEmail, adminType, brokerEmail).getEntity();
						
						GetUserFromDBByCompanyResponse getUserFromDBByCompanyResponse = gson
								.fromJson(getUserFromDBByCompany, GetUserFromDBByCompanyResponse.class);
						//HashMap<String, String> uniqueUsers = new HashMap<>();

						HashMap<String, UserCreationRequest> mapUserDB = new HashMap<>();
						List<String> usernames = null;
						if (getUserFromDBByCompanyResponse != null
								&& getUserFromDBByCompanyResponse.getItems() != null) {
							usernames= new ArrayList<String>();
							String companyName = null;
							for (int countDBResp = 0; countDBResp < getUserFromDBByCompanyResponse.getItems()
									.size(); countDBResp++) {
								//String adLoginName = getUserFromDBByCompanyResponse.getItems().get(countDBResp)
									//	.getUserInformation().getLogonName();
								companyName = getUserFromDBByCompanyResponse.getItems().get(countDBResp)
										.getUserInformation().getLogonName();
								mapUserDB.put(companyName, getUserFromDBByCompanyResponse.getItems().get(countDBResp));
								//This is for getting the information from Theia
								if(getUserFromDBByCompanyResponse.getItems().get(countDBResp)
										.getUserInformation().getTenantType()!=null && !"Internal".equalsIgnoreCase(getUserFromDBByCompanyResponse.getItems().get(countDBResp).getUserInformation().getTenantType())) {
									usernames.add(getUserFromDBByCompanyResponse.getItems().get(countDBResp).getUserInformation().getEmail());
								}
								else {
									usernames.add(getUserFromDBByCompanyResponse.getItems().get(countDBResp).getUserInformation().getLogonName());
								}
									
							}
							//usernames = new ArrayList<String>(mapUserDB.keySet());
							
						}
						
						
						//If usernames list not null, get the information from Theia for all the users
						HashMap<String, ThieaAuditInfo> mapThieaInfo = new HashMap<>();
						if(usernames!=null && usernames.size()>0) {
							List<ThieaAuditInfo> lstTheiaAuditInfo = apiServices.getTheiaAuditInfoForUsers(usernames) ;
							for(ThieaAuditInfo thieaAuditInfo : lstTheiaAuditInfo) {
								mapThieaInfo.put(thieaAuditInfo.getUserName(),thieaAuditInfo);
							}
						}
						
						if (getUserFromDBByCompanyResponse != null
								&& getUserFromDBByCompanyResponse.getItems() != null) 
						{
						
							for (int countDBResp = 0; countDBResp < getUserFromDBByCompanyResponse.getItems().size(); countDBResp++) 
							{
								UserInfoBPM userInfoBPM = new UserInfoBPM();
								UserCreationRequest currentUserCreationRequest = getUserFromDBByCompanyResponse.getItems().get(countDBResp);
								userInfoBPM = currentUserCreationRequest.getUserInformation();
								userInfoBPM.setFirstName(adUser[0].getFirstName());
								userInfoBPM.setMiddleName(adUser[0].getMiddleName());
								userInfoBPM.setLastName(adUser[0].getLastName());
								userInfoBPM.setPhone(adUser[0].getPhone());
								userInfoBPM.setTitle(adUser[0].getTitle());
								userInfoBPM.setCompany(adUser[0].getCompany());
								userInfoBPM.setCognosTenantId(adUser[0].getCognosTenantId());
								userInfoBPM.setAccountEnable(adUser[0].isAccountEnable());
								
								userInfoBPM.setPwdLastSet(adUser[0].getPwdLastSet());
								userInfoBPM.setAccountLocked(adUser[0].isAccountLocked());
								userInfoBPM.setNoOfBadAttempts(adUser[0].getNoOfBadAttempts());
								userInfoBPM.setPasswordExpired(adUser[0].isPasswordExpired());
								//Setting Thiea Value
								if(userInfoBPM.getTenantType()!=null && !"Internal".equalsIgnoreCase(userInfoBPM.getTenantType())){
									if(mapThieaInfo.containsKey(adUser[0].getEmail())) {
										ThieaAuditInfo currentThieaAuditInfo = mapThieaInfo.get(adUser[0].getEmail());
										userInfoBPM.setLastTheiaLogin(currentThieaAuditInfo.getTimestamp());
								
									}
								}else {
									if(mapThieaInfo.containsKey(adUser[0].getLoginName())) {
										ThieaAuditInfo currentThieaAuditInfo = mapThieaInfo.get(adUser[0].getLoginName());
										userInfoBPM.setLastTheiaLogin(currentThieaAuditInfo.getTimestamp());
								
									}
								}
									
								
								//Setting if the user is an APA
								userInfoBPM.setAPA(false);
								if(adUser[0].getMemberOf()!=null&&adUser[0].getMemberOf().size()>0) {
									for(int count=0;count<adUser[0].getMemberOf().size();count++)
									{
										if(adUser[0].getMemberOf().get(count).indexOf("CN=PCV_APA")>-1) {
											userInfoBPM.setAPA(true);
											break;
										}
										
									}
								}//End
	
								// Get Company and Permissions
								if (currentUserCreationRequest.getCompanyFlatStructure() != null
										&& (currentUserCreationRequest.getCompanyFlatStructure().getItems() != null
												&& currentUserCreationRequest.getCompanyFlatStructure().getItems()
														.size() > 0)) {
									userInfoBPM.setCompanyAndPermissions(
											currentUserCreationRequest.getCompanyFlatStructure().getItems().get(0));
									if(userInfoBPM.getCompanyAndPermissions().isAccountDisabled()) {
										userInfoBPM.setAccountEnable(false);
									}
								}
	
								// Getting the Additional UserInformation
								if (currentUserCreationRequest.getAdditionalUserInfo() != null) {
									userInfoBPM.setAdditionalUserInfo(
											currentUserCreationRequest.getAdditionalUserInfo());
								}
	
								lstUserInfoBPM.add(userInfoBPM);
							
							}

						}
						activeUsersForCompanyResponse.setUsers(lstUserInfoBPM);

										activeUsersForCompanyResponseJSON = gson.toJson(activeUsersForCompanyResponse);
						return Response.status(200).entity(activeUsersForCompanyResponseJSON).build();
					} else {
						return Response.status(200).entity(activeUsersForCompanyResponseJSON).build();
					}

				} else {
					return Response.status(200).entity(activeUsersForCompanyResponseJSON).build();
				}

			} else {
				return Response.status(501).entity(responseBody).build();
			}
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();

		}
	}
	
	
	/**
	 * @param company
	 *            - company for getInflightUserOnboarding
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("bpmoc/getUserFromDBByAdminType/{company}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response getUserFromDBByAdminType(@PathParam("adminEmail") String adminEmail,@PathParam("adminType") String adminType,@PathParam("brokerLoginName") String brokerLoginName) throws Exception {

		logger.debug("--Start getUserFromDBByAdminType-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.bcbsar.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		////JsonParser parser = new JsonParser();
		String jsonRequestForm = "{\"adminEmail\":\"" + adminEmail + "\", \"adminType\":\"" + adminType + "\", \"brokerLoginName\":\"" + brokerLoginName + "\"}";
		Form form = new Form().param("params", jsonRequestForm);

		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40DB_Get%20Broker%20Info%20By%20Admin%20Type")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");
			UserCreationRequest userCreationRequest = gson.fromJson(dataJsonObj, UserCreationRequest.class);

			// logger.debug("<---userCreationRequest---getRecordId----->"+userCreationRequest.getRecordId());
			logger.debug("<---getUserFromDBByCompany---getRecordId----->" + userCreationRequest.getUserInformation());
			// logger.debug("<---getUserFromDBByCompany--------->"+dataJsonObj.get("userCreationRequest").isJsonNull());
			if (!dataJsonObj.get("userCreationRequest").isJsonNull()) {
				JsonObject inflightUserOnboardingList = o.getAsJsonObject("data").getAsJsonObject("data")
						.getAsJsonObject("userCreationRequest");
				if (!inflightUserOnboardingList.isJsonNull()
						&& (!inflightUserOnboardingList.getAsJsonArray("items").isJsonNull()
								&& inflightUserOnboardingList.getAsJsonArray("items").size() > 0)) {
					GetUserFromDBByCompanyResponse getUserFromDBByCompanyResponse = gson
							.fromJson(inflightUserOnboardingList, GetUserFromDBByCompanyResponse.class);
					logger.debug("<---getUserFromDBByCompanyResponse---size----->"
							+ getUserFromDBByCompanyResponse.getItems().size());
					logger.debug("<---getUserFromDBByCompanyResponse--getTenantType----->"
							+ getUserFromDBByCompanyResponse.getItems().get(0).getUserInformation().getTenantType());

					String getUserFromDBByCompanyJson = gson.toJson(getUserFromDBByCompanyResponse);

					jsonObject.addProperty("response", getUserFromDBByCompanyJson);
					result = "" + jsonObject;
					logger.debug("--End getUserFromDBByCompany--");
					return Response.status(200).entity(getUserFromDBByCompanyJson).build();

				}
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}
}