package com.ar.bcbs.ad.dao;

public class ReAuthInfo {
	private String userName;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTenantType() {
		return tenantType;
	}
	public void setTenantType(String tenantType) {
		this.tenantType = tenantType;
	}
	public String getAccess() {
		return access;
	}
	public void setAccess(String access) {
		this.access = access;
	}
	public String getPermission() {
		return permission;
	}
	public void setPermission(String permission) {
		this.permission = permission;
	}
	public boolean isReauthed() {
		return isReauthed;
	}
	public void setReauthed(boolean isReauthed) {
		this.isReauthed = isReauthed;
	}
	public String getReAuthInitiated() {
		return reAuthInitiated;
	}
	public void setReAuthInitiated(String reAuthInitiated) {
		this.reAuthInitiated = reAuthInitiated;
	}
	public boolean isReAuthRequired() {
		return isReAuthRequired;
	}
	public void setReAuthRequired(boolean isReAuthRequired) {
		this.isReAuthRequired = isReAuthRequired;
	}
	private String email;
	private String tenantType;
	private String access;
	private String permission;
	private boolean isReauthed;
	private String reAuthInitiated;
	private boolean isReAuthRequired;
	
}

