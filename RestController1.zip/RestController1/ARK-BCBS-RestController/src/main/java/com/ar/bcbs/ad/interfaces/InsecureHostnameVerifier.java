package com.ar.bcbs.ad.interfaces;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

public class InsecureHostnameVerifier implements HostnameVerifier {
    @Override
    public boolean verify(String hostname, SSLSession session) {
        System.out.println("Verified InsecurHostName");
    	return true;
    }
}