package com.ar.bcbs.ad.messages;

import java.util.List;

import com.ar.bcbs.ad.dao.ADUserAttributes;

public class SearchActiveDirectoryResponse {
	List<ADUserAttributes> response;

	public List<ADUserAttributes> getResponse() {
		return response;
	}

	public void setResponse(List<ADUserAttributes> response) {
		this.response = response;
	}
	
}
