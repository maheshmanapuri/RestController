package com.ar.bcbs.ad.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.ar.bcbs.ad.dao.DBConnectObject;
import com.ar.bcbs.ad.interfaces.InsecureHostnameVerifier;
import com.ar.bcbs.ad.interfaces.ServerTrustManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

public class DBServices {

	private Gson gson;

	private String INTERNAL_TOMCAT = null;
	private static Properties appProps = null;

	final static Logger logger = Logger.getLogger(DBServices.class);

	public DBServices() {
		this.gson = new Gson();
		String rootPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
		String appConfigPath = rootPath + "environment.properties";
		// logger.debug("--Start getAllADGroups--");

		appProps = new Properties();
		try {
			appProps.load(new FileInputStream(appConfigPath));
			INTERNAL_TOMCAT = appProps.getProperty("INTERNAL_TOMCAT");
		} catch (IOException e) {
			logger.debug("Exception in Class Override :" + e);
			// e.printStackTrace();
		}

		// Client client = ClientBuilder.newClient();
		// HttpAuthenticationFeature feature =
		// HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		// client.register(feature);
	}
	public Response queryDB(DBConnectObject dbObj) {
		
		
		
		JsonObject jsonObject = new JsonObject();
		String result = "";
		Client client = ClientBuilder.newClient();
		//String responseBody = null;
		gson = new GsonBuilder().setLenient().create();
	
	
		logger.debug("<---New client with Proxy--------->");
		SSLContext sc;
		try {
			sc = SSLContext.getInstance("TLSv1.2");
		
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		try {
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid)
				.build();
		
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// Java 8
		// End

		
		try {
			//Form form = new Form();
			//form.param("action", "complete").param("params", completeJSONRequest);
			
			Response response = client.target(INTERNAL_TOMCAT).path("/ARK-BCBS-UtilityServices/crest/domain/queryDB")
					.request(MediaType.APPLICATION_JSON).post(Entity.json(dbObj));

			//responseBody = response.readEntity(String.class);
			//System.out.println("DBQuery Response Body-->"+responseBody);
			return response;
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}
	
public Response insertDB(DBConnectObject dbObj) {
		
		
		
		JsonObject jsonObject = new JsonObject();
		String result = "";
		Client client = ClientBuilder.newClient();
		//String responseBody = null;
		gson = new GsonBuilder().setLenient().create();
	
	
		logger.debug("<---New client with Proxy--------->");
		SSLContext sc;
		try {
			sc = SSLContext.getInstance("TLSv1.2");
		
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		try {
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid)
				.build();
		
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// Java 8
		// End

		
		try {
			//Form form = new Form();
			//form.param("action", "complete").param("params", completeJSONRequest);
			
			Response response = client.target(INTERNAL_TOMCAT).path("/ARK-BCBS-UtilityServices/crest/domain/updateDB")
					.request(MediaType.APPLICATION_JSON).post(Entity.json(dbObj));

			//responseBody = response.readEntity(String.class);
			//System.out.println("DBQuery Response Body-->"+responseBody);
			return response;
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}
}
