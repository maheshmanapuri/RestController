package com.ar.bcbs.ad.dao;

public class UserInfoBPM {
	private String firstName;
	private String middleName;
	private String lastName;
	private String phone;
	private String title;
	private String company;
	private String cognosTenantId;
	
	private Integer userId;
	private String tenantType;
	private String logonName;
	private String email;
	private String elCarrier;
	private String elType;
	private boolean isExternal;
	private String isInteractiveReporting;
	private String focusCare;
	private boolean isAPA;
	private boolean isAccountEnable;
	private CompanyAndPermissionsBPM companyAndPermissions;
	private AdditionalUserInfoBPM additionalUserInfo;
	
	//For Admin Screen
	private String pwdLastSet;
	private boolean isAccountLocked;
	private int noOfBadAttempts;
	private boolean isPasswordExpired;
	private String lastTheiaLogin;
	private String lastManageUserLogin;
	
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getTenantType() {
		return tenantType;
	}
	public void setTenantType(String tenantType) {
		this.tenantType = tenantType;
	}
	public String getLogonName() {
		return logonName;
	}
	public void setLogonName(String logonName) {
		this.logonName = logonName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getElCarrier() {
		return elCarrier;
	}
	public void setElCarrier(String elCarrier) {
		this.elCarrier = elCarrier;
	}
	public String getElType() {
		return elType;
	}
	public void setElType(String elType) {
		this.elType = elType;
	}
	public boolean isExternal() {
		return isExternal;
	}
	public void setExternal(boolean isExternal) {
		this.isExternal = isExternal;
	}
	public String getIsInteractiveReporting() {
		return isInteractiveReporting;
	}
	public void setIsInteractiveReporting(String isInteractiveReporting) {
		this.isInteractiveReporting = isInteractiveReporting;
	}
	public String getFocusCare() {
		return focusCare;
	}
	public void setFocusCare(String focusCare) {
		this.focusCare = focusCare;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getCognosTenantId() {
		return cognosTenantId;
	}
	public void setCognosTenantId(String cognosTenantId) {
		this.cognosTenantId = cognosTenantId;
	}
	public CompanyAndPermissionsBPM getCompanyAndPermissions() {
		return companyAndPermissions;
	}
	public void setCompanyAndPermissions(CompanyAndPermissionsBPM companyAndPermissions) {
		this.companyAndPermissions = companyAndPermissions;
	}
	public AdditionalUserInfoBPM getAdditionalUserInfo() {
		return additionalUserInfo;
	}
	public void setAdditionalUserInfo(AdditionalUserInfoBPM additionalUserInfo) {
		this.additionalUserInfo = additionalUserInfo;
	}
	public boolean isAPA() {
		return isAPA;
	}
	public void setAPA(boolean isAPA) {
		this.isAPA = isAPA;
	}
	public boolean isAccountEnable() {
		return isAccountEnable;
	}
	public void setAccountEnable(boolean isAccountEnable) {
		this.isAccountEnable = isAccountEnable;
	}
	public String getPwdLastSet() {
		return pwdLastSet;
	}
	public void setPwdLastSet(String pwdLastSet) {
		this.pwdLastSet = pwdLastSet;
	}
	public boolean isAccountLocked() {
		return isAccountLocked;
	}
	public void setAccountLocked(boolean isAccountLocked) {
		this.isAccountLocked = isAccountLocked;
	}
	public int getNoOfBadAttempts() {
		return noOfBadAttempts;
	}
	public void setNoOfBadAttempts(int noOfBadAttempts) {
		this.noOfBadAttempts = noOfBadAttempts;
	}
	public boolean isPasswordExpired() {
		return isPasswordExpired;
	}
	public void setPasswordExpired(boolean isPasswordExpired) {
		this.isPasswordExpired = isPasswordExpired;
	}
	public String getLastTheiaLogin() {
		return lastTheiaLogin;
	}
	public void setLastTheiaLogin(String lastTheiaLogin) {
		this.lastTheiaLogin = lastTheiaLogin;
	}
	public String getLastManageUserLogin() {
		return lastManageUserLogin;
	}
	public void setLastManageUserLogin(String lastManageUserLogin) {
		this.lastManageUserLogin = lastManageUserLogin;
	}
	
	
}
