package com.ar.bcbs.ad.messages;

public class SearchActiveDirectory {
	
	private String searchParam;
	private String filterSearch;
	public String getSearchParam() {
		return searchParam;
	}
	public void setSearchParam(String searchParam) {
		this.searchParam = searchParam;
	}
	public String getFilterSearch() {
		return filterSearch;
	}
	public void setFilterSearch(String filterSearch) {
		this.filterSearch = filterSearch;
	}
}
