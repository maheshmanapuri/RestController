package com.umb.util;

import org.apache.commons.codec.binary.Base64;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.apache.commons.codec.binary.Base64;
import com.google.gson.Gson;
import com.umb.rest.ad.dao.JWTBody;

public class JWTServices {

	@SuppressWarnings("unused")
	public String extractPayload(String token) throws Exception {
    	
    	try {
    		 
    		Algorithm algorithm = Algorithm.HMAC256("UMB@123Pass");
    		 
    	    JWTVerifier verifier = JWT.require(algorithm)
    	        .withIssuer("auth0")
    	        .build(); //Reusable verifier instance
    	    
			//DecodedJWT jwt = verifier.verify(token);
			
    	   
    	    

    	    
    	    String[] split_string = token.split("\\.");
            String base64EncodedHeader = split_string[0];
            String base64EncodedBody = split_string[1];
            @SuppressWarnings("unused")
			String base64EncodedSignature = split_string[2];

            System.out.println("~~~~~~~~~ JWTServices Header ~~~~~~~");
            Base64 base64Url = new Base64(true);
            String header = new String(base64Url.decode(base64EncodedHeader));
            System.out.println("JWTServices Header : " + header);


            System.out.println("~~~~~~~~~ JWTServices Body ~~~~~~~");
            String body = new String(base64Url.decode(base64EncodedBody));
            Gson gson = new Gson();
            JWTBody jwtBody = gson.fromJson(body, JWTBody.class);
            
            System.out.println("JWTServices Body : "+ jwtBody.getUserInformation());        
            System.out.println("Token has been verified succesfully");
    	    return jwtBody.getUserInformation();
    	    
    	    
    	   
    	} catch (JWTVerificationException exception){
    		throw exception;
    	    //Invalid signature/claims
    	}
        // Check if the token was issued by the server and if it's not expired
        // Throw an Exception if the token is invalid
    }
    
    
   /* public static void main (String args[]) {
    	String jwtToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVc2VyIEF1dGhlbnRpY2F0aW9uIiwiVXNlckluZm9ybWF0aW9uIjoiMTIzMjQiLCJpc3MiOiJhdXRoMCIsImV4cCI6MTYwNTE5NDY3Nn0.RMdYGA3_NH2rSRO7I1Uc2jNgu12_VP9gQw_ex9sFlYA";
    	try {
			extractToken(jwtToken);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }*/
}
