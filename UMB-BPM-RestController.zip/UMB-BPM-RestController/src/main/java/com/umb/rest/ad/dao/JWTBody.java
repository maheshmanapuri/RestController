package com.umb.rest.ad.dao;

public class JWTBody {
	private String sub;
	private String UserInformation;
	private String iss;
	private int exp;
	public String getSub() {
		return sub;
	}
	public void setSub(String sub) {
		this.sub = sub;
	}
	public String getUserInformation() {
		return UserInformation;
	}
	public void setUserInformation(String userInformation) {
		UserInformation = userInformation;
	}
	public String getIss() {
		return iss;
	}
	public void setIss(String iss) {
		this.iss = iss;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp) {
		this.exp = exp;
	}
	
	
}