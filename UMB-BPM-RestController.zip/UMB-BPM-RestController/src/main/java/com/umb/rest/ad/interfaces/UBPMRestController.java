package com.umb.rest.ad.interfaces;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;
import javax.xml.ws.spi.http.HttpContext;

import org.apache.log4j.Logger;
import org.glassfish.jersey.apache.connector.ApacheConnectorProvider;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.umb.util.JWTServices;

@Path("services")
@Provider
public class UBPMRestController {
	private Gson gson;

	// private Client client;
	private String BPM_USERNAME = null;
	private String BPM_PASSWORD = null;
	private String BPM_URL = null;
	
	private static Properties appProps = null;

	final static Logger logger = Logger.getLogger(UBPMRestController.class);
	//APIServices apiServices = new APIServicesImpl();
	JWTServices jwtServices = new JWTServices();
	
	public UBPMRestController() {
		this.gson = new Gson();
		String rootPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
		String appConfigPath = rootPath + "environment.properties";
		// logger.debug("--Start getAllADGroups--");

		appProps = new Properties();
		try {
			appProps.load(new FileInputStream(appConfigPath));
			
		
			BPM_USERNAME = appProps.getProperty("BPM_USERNAME");
			BPM_PASSWORD = appProps.getProperty("BPM_PASSWORD");
			BPM_URL = appProps.getProperty("BPM_URL");
			
		
			
		} catch (IOException e) {
			logger.debug("Exception in Class Override :" + e);
			// e.printStackTrace();
		}

		// Client client = ClientBuilder.newClient();
		// HttpAuthenticationFeature feature =
		// HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		// client.register(feature);
	}

	
	
	
	
	/**
	 * @param taskId
	 *            - taskID for getTaskDetails
	 * @return json - bpm rest response
	 * @throws Exception
	 */

	@GET
	@Path("getTaskDetails/{taskId}")
	@Produces(MediaType.APPLICATION_JSON)
	//@Secured

	public Response getTaskDetails(@PathParam("taskId") String taskId) throws Exception {

		logger.debug("--Start getTaskDetails for--: " + taskId);

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				////.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.umb.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("part", "all")
					.request(MediaType.APPLICATION_JSON).get();

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param taskId
	 *            - taskID for getTaskDetails
	 * @return json - bpm rest response
	 * @throws Exception
	 */

	@PUT
	@Path("assigntask/{taskId}")
	@Produces(MediaType.APPLICATION_JSON)
	//@Secured
	public Response assignTask(@PathParam("taskId") String taskId) throws Exception {
		logger.debug("--Start assignTask to External for--: " + taskId);

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				////.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.umb.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("action", "assign")
					.queryParam("toMe", "true").request(MediaType.APPLICATION_JSON)
					.put(Entity.entity("", MediaType.APPLICATION_JSON));

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param taskId
	 *            - taskID for re-assign task back to owner
	 * @return JSON - BPM rest response
	 * @throws Exception
	 */

	@PUT
	@Path("assigntaskBack/{taskId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response assigntaskBack(@PathParam("taskId") String taskId) throws Exception {
		logger.debug("--Start assignTask to Original Owner for--: " + taskId);

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				//.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.umb.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("action", "assign")
					.queryParam("back", "true").request(MediaType.APPLICATION_JSON)
					.put(Entity.entity("", MediaType.APPLICATION_JSON));

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param taskId
	 *            -taskId to complete Task
	 * @param completeJSONRequest
	 *            -completeJSONRequest to complete Task
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("completetask/{taskId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response completeTask(@PathParam("taskId") String taskId, String completeJSONRequest) throws Exception {
		logger.debug("--Start completetask--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				//.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.umb.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Form form = new Form();
			form.param("action", "complete").param("params", completeJSONRequest);
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("action", "complete")
					.queryParam("part", "all").request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}

	/**
	 * @param company
	 *            - company name
	 * @param userEmail
	 *            - users email
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("initateUserOnboardingProcess")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response initateUserOnboardingProcess(String completeJSONRequest) throws Exception {
		logger.debug("--Start initateUserOnboardingProcess--");

		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				//.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.umb.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Form form = new Form();
			form.param("action", "complete").param("params", completeJSONRequest);
			Response response = client.target(BPM_URL).path("process").queryParam("action", "start")
					.queryParam("bpdId", "25.85c8e71d-6ed0-444d-9a74-5358ada9a13d")
					.queryParam("processAppId", "2066.f4b32441-58c6-4728-8009-15f1b67dc278").queryParam("part", "all")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			// https://arkbluecross.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/process?action=start&bpdId=&processAppId=&params=%7B%22userEmail%22%3A%22test%40test.com%22%2C%22company%22%3A%22OPPORTUNITIES+INC+(4863)%22%7D&parts=header
			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}

	/**
	 * @param piid
	 *            - process Instance ID
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@POST
	@Path("deleteUserOnboardingProcess")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response deleteUserOnboardingProcess(String completeJSONRequest) throws Exception {

		logger.debug("--Start deleteUserOnboardingProcess-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				//.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.umb.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		// String jsonRequestForm = "{\"company\":\""+company+"\"}";
		Form form = new Form().param("params", completeJSONRequest);

		try {
			Response response = client.target(BPM_URL).path("/service/UMBONB%40DeleteUserOnboardingProcess_Service")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			// logger.debug("<---o--------->"+o);
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

			logger.debug("<---deleteUserOnboardingProcess--------->" + dataJsonObj.get("status").isJsonNull());
			if (!dataJsonObj.get("status").isJsonNull()) {
				JsonObject data = o.getAsJsonObject("data").getAsJsonObject("data");
				if (!data.isJsonNull()) {
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(data);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);

				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * 
	 * @return json - current env property
	 * @throws Exception
	 */
	@GET
	@Path("getCurrentEnvProperties")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured

	public Response getCurrentEnvProperties() throws Exception {

		// logger.debug("--Start getCurrentEnvProperties-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";

		try {
			responsePayload = new JsonObject();
			responsePayload.addProperty("response", BPM_URL);

			String responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}

	/**
	 * @param company
	 *            - company for getInflightUserOnboarding
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("getUsersFromBPMTeam/{bpmteam}")
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response getUsersFromBPMTeam(@PathParam("bpmteam") String bpmteam) throws Exception {

		logger.debug("--Start getUsersFromBPMTeam-- ");

		JsonObject jsonObject = new JsonObject();
		JsonObject responsePayload = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				//.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.umb.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);
		//JsonParser parser = new JsonParser();
		String jsonRequestForm = "{\"data\":\"" + bpmteam + "\"}";
		Form form = new Form().param("params", jsonRequestForm);
		
		try {
			Response response = client.target(BPM_URL).path("/service/BCBSONB%40Get%20Users%20from%20BPM%20Team")
					.queryParam("action", "start").queryParam("createTask", "false").queryParam("parts", "data")
					.request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			JsonObject o = JsonParser.parseString(responseBody).getAsJsonObject();
			//logger.debug("<---o--------->" + o);
			JsonArray items = null;
			String responseString = null;

			JsonObject dataJsonObj = o.getAsJsonObject("data").getAsJsonObject("data");

			logger.debug("<---getUsersFromBPMTeam--------->" + dataJsonObj.get("results").isJsonNull());
			if (!dataJsonObj.get("results").isJsonNull()) {
				JsonObject results = o.getAsJsonObject("data").getAsJsonObject("data").getAsJsonObject("results");
				if (!results.isJsonNull() && (!results.getAsJsonArray("items").isJsonNull()
						&& results.getAsJsonArray("items").size() > 0)) {
					items = results.getAsJsonArray("items");
					com.google.gson.JsonElement jsonElement = gson.toJsonTree(items);
					responsePayload = new JsonObject();
					responsePayload.add("response", jsonElement);
				}

				/*
				 * JsonPrimitive responseJSON = o.getAsJsonPrimitive("data");
				 * logger.debug("<------------->");
				 * logger.debug(" o.getAsJsonPrimitive(\"response\")\n"+
				 * o.getAsJsonPrimitive("data"));
				 */
			} else {
				responsePayload = new JsonObject();
				responsePayload.addProperty("response", "");
			}
			responseString = responsePayload.toString();
			return Response.status(200).entity(responseString).build();
		} catch (Exception exception) {
			logger.debug("Caught Exception " + exception);
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}
	}
	
	
	/**
	 * @param taskId
	 *            -taskId to approve Task
	 * @param completeJSONRequest
	 *            -completeJSONRequest to complete Task
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("approve")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response approveTask(@HeaderParam ("Authorization") String token) throws Exception {
		
		logger.debug("--Start approvetask--");
		String taskId = jwtServices.extractPayload(token);
		assignTask(taskId);
		
		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				//.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.umb.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Form form = new Form();
			form.param("action", "complete").param("params", "{\"status\":\"approve\"}");
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("action", "complete")
					.queryParam("part", "all").request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}
	
	/**
	 * @param taskId
	 *            -taskId to reject Task
	 * @param completeJSONRequest
	 *            -completeJSONRequest to complete Task
	 * @return json - bpm rest response
	 * @throws Exception
	 */
	@GET
	@Path("reject")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Secured
	public Response rejectTask(@HeaderParam ("Authorization") String token) throws Exception {
		logger.debug("--Start rejectTask--");
		
		
		String taskId = jwtServices.extractPayload(token);
		
		
		assignTask(taskId);
	
		
		JsonObject jsonObject = new JsonObject();
		String result = "";
		// Client client = ClientBuilder.newClient();
		// Added to check proxy--Start
		Client client = null;
		//// ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		gson = new GsonBuilder().setLenient().create();

		ClientConfig clientConfig = new ClientConfig()
				//.connectorProvider(new ApacheConnectorProvider())
				.property(ClientProperties.PROXY_URI, "http://wsaproxy.umb.net:8080");

		/*
		 * clientBuilder.withConfig(clientConfig); client = clientBuilder.build();
		 */

		logger.debug("<---New client with Proxy--------->");
		// Added to check proxy--End

		// Added for TSLV1.2
		SSLContext sc = SSLContext.getInstance("TLSv1.2");// Java 8
		System.setProperty("https.protocols", "TLSv1.2");// Java 8

		TrustManager[] trustAllCerts = { new ServerTrustManager() };
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HostnameVerifier allHostsValid = new InsecureHostnameVerifier();
		client = ClientBuilder.newBuilder().sslContext(sc).hostnameVerifier(allHostsValid).withConfig(clientConfig)
				.build();
		// End

		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(BPM_USERNAME, BPM_PASSWORD);
		client.register(feature);

		try {
			Form form = new Form();
			form.param("action", "complete").param("params", "{\"status\":\"reject\"}");
			Response response = client.target(BPM_URL).path("task/" + taskId).queryParam("action", "complete")
					.queryParam("part", "all").request(MediaType.APPLICATION_JSON).post(Entity.form(form));

			String responseBody = response.readEntity(String.class);
			return Response.status(200).entity(responseBody).build();
		} catch (Exception exception) {
			// logger.debug("Caught Exception "+exception);
			// logger.debug("client.toString())--> "+client.toString());
			jsonObject = new JsonObject();
			jsonObject.addProperty("response", gson.toJson(exception.getMessage()));
			result = "" + jsonObject;
			return Response.status(501).entity(result).build();
		}

	}


}