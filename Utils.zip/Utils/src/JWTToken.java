

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;


public class JWTToken {

	
	@SuppressWarnings("unused")
	private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	public static String JWTTokenGenerator(String loginName, String password,Integer minutes) throws Exception {
		System.out.println("--Start JWTTokenGenerator--");

		try {
				
				String token = null;
				Date tokenExpireDate = new java.util.Date();
				
		        // convert date to calendar
		        Calendar c = Calendar.getInstance();
		        c.setTime(tokenExpireDate);

		        // manipulate date
		        //c.add(Calendar.DATE, 1); //same with c.add(Calendar.DAY_OF_MONTH, 1);
		        c.add(Calendar.MINUTE, minutes);
		        // convert calendar to date
		        Date currentDatePlusOne = c.getTime();

		        //logger.debug(dateFormat.format(currentDatePlusOne));
				
				
				Algorithm algorithm = Algorithm.HMAC256(password);
			    token = JWT.create().withSubject("User Authentication")
			    		.withExpiresAt(currentDatePlusOne)
			    		.withClaim("UserInformation",(loginName == null) ? null : loginName)
			    		.withIssuer("auth0")
			    		.sign(algorithm);
			    
			    
			    System.out.println("--End JWTTokenGenerator--");
				return token;
			
			}
			catch (Exception exception){
				 System.out.println("Caught Exception "+exception);
				
				return null;
				
				
			}
	}
	
	public boolean validateJWTToken(String token,String password) throws Exception {
    	boolean valid = true;
    	try {
    	    Algorithm algorithm = Algorithm.HMAC256(password);
    	    JWTVerifier verifier = JWT.require(algorithm)
    	        .withIssuer("auth0")
    	        .build(); //Reusable verifier instance
    	    @SuppressWarnings("unused")
			DecodedJWT jwt = verifier.verify(token);
    	    
    	    System.out.println("Token has been verified succesfully");
    	} catch (JWTVerificationException exception){
    		valid = false;
    	}
    		return valid;
    	}
	
	
}